<?php
/**
 * Visible FAQ section matching the FAQPage JSON-LD in inc/aeo-geo.php.
 * Rendering the same Q&A pairs on-page (not just in schema) is what lets
 * both Google's FAQ rich results and AI answer engines quote them.
 *
 * @package Bookboochi
 */

$faq_pairs = bookboochi_get_faq_pairs( get_the_ID() );
if ( empty( $faq_pairs ) ) {
	return;
}
?>
<section class="bb-faq" aria-labelledby="bb-faq-heading">
	<h2 id="bb-faq-heading"><?php esc_html_e( 'Frequently asked questions', 'bookboochi' ); ?></h2>
	<?php foreach ( $faq_pairs as $pair ) : ?>
		<div class="bb-faq-item" style="margin-bottom:1.4em;">
			<h3 style="font-size:1.05rem;margin-bottom:0.3em;"><?php echo esc_html( $pair['question'] ); ?></h3>
			<p><?php echo esc_html( $pair['answer'] ); ?></p>
		</div>
	<?php endforeach; ?>
</section>
