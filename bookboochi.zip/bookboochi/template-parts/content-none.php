<?php
/**
 * Shown when a query returns no posts.
 *
 * @package Bookboochi
 */
?>
<div class="bb-card-body" style="text-align:center;padding:3rem 1rem;">
	<h1><?php esc_html_e( 'Nothing here yet', 'bookboochi' ); ?></h1>
	<?php if ( is_search() ) : ?>
		<p><?php esc_html_e( 'No results matched your search. Try a different word or two.', 'bookboochi' ); ?></p>
		<?php get_search_form(); ?>
	<?php else : ?>
		<p><?php esc_html_e( 'No posts to show here yet — check back soon.', 'bookboochi' ); ?></p>
	<?php endif; ?>
</div>
