<?php
/**
 * Structured "Book Review" details box, rendered inside single.php when a
 * post has book-review meta filled in. The visible markup here matches
 * the Book + Review JSON-LD emitted in inc/aeo-geo.php, so what a reader
 * sees and what a machine reads describe the same facts.
 *
 * @package Bookboochi
 */

$post_id     = get_the_ID();
$book_title  = get_post_meta( $post_id, '_bb_book_title', true );
$book_author = get_post_meta( $post_id, '_bb_book_author', true );
$genre       = get_post_meta( $post_id, '_bb_book_genre', true );
$publisher   = get_post_meta( $post_id, '_bb_book_publisher', true );
$isbn        = get_post_meta( $post_id, '_bb_book_isbn', true );
$pages       = get_post_meta( $post_id, '_bb_book_pages', true );
$rating      = get_post_meta( $post_id, '_bb_book_rating', true );
$verdict     = get_post_meta( $post_id, '_bb_verdict', true );
$buy_link    = get_post_meta( $post_id, '_bb_buy_link', true );

if ( empty( $book_title ) ) {
	return;
}

// See bookboochi_linked_terms_or_text() in inc/template-tags.php: links to
// the Bookboochi Library plugin's Author/Genre archive pages when this
// post has matching taxonomy terms, else falls back to the plain text
// typed into this box's own Author/Genre fields (unchanged behavior).
$book_author_html = bookboochi_linked_terms_or_text( $post_id, 'bbl_author', $book_author );
$genre_html        = bookboochi_linked_terms_or_text( $post_id, 'bbl_genre', $genre );
?>
<aside class="bb-book-review-box" aria-label="<?php esc_attr_e( 'Book review summary', 'bookboochi' ); ?>">
	<h2><?php esc_html_e( 'Book at a glance', 'bookboochi' ); ?></h2>

	<dl class="bb-review-grid">
		<div>
			<dt><?php esc_html_e( 'Title', 'bookboochi' ); ?></dt>
			<dd><?php echo esc_html( $book_title ); ?></dd>
		</div>
		<?php if ( $book_author_html ) : ?>
			<div>
				<dt><?php esc_html_e( 'Author', 'bookboochi' ); ?></dt>
				<dd><?php echo wp_kses_post( $book_author_html ); ?></dd>
			</div>
		<?php endif; ?>
		<?php if ( $genre_html ) : ?>
			<div>
				<dt><?php esc_html_e( 'Genre', 'bookboochi' ); ?></dt>
				<dd><?php echo wp_kses_post( $genre_html ); ?></dd>
			</div>
		<?php endif; ?>
		<?php if ( $publisher ) : ?>
			<div>
				<dt><?php esc_html_e( 'Publisher', 'bookboochi' ); ?></dt>
				<dd><?php echo esc_html( $publisher ); ?></dd>
			</div>
		<?php endif; ?>
		<?php if ( $pages ) : ?>
			<div>
				<dt><?php esc_html_e( 'Pages', 'bookboochi' ); ?></dt>
				<dd><?php echo esc_html( $pages ); ?></dd>
			</div>
		<?php endif; ?>
		<?php if ( $isbn ) : ?>
			<div>
				<dt><?php esc_html_e( 'ISBN', 'bookboochi' ); ?></dt>
				<dd><?php echo esc_html( $isbn ); ?></dd>
			</div>
		<?php endif; ?>
	</dl>

	<?php if ( '' !== $rating ) : ?>
		<p class="bb-review-rating-display">
			<span class="bb-rating" aria-hidden="true"><?php echo esc_html( bookboochi_render_stars( $rating ) ); ?></span>
			<strong><?php echo esc_html( $rating ); ?>/5</strong>
		</p>
	<?php endif; ?>

	<?php if ( $verdict ) : ?>
		<p class="bb-review-verdict">“<?php echo esc_html( $verdict ); ?>”</p>
	<?php endif; ?>

	<?php if ( $buy_link ) : ?>
		<div class="bb-buy-links">
			<a class="bb-btn" href="<?php echo esc_url( $buy_link ); ?>" rel="nofollow sponsored noopener" target="_blank">
				<?php esc_html_e( 'Find this book', 'bookboochi' ); ?>
			</a>
		</div>
	<?php endif; ?>
</aside>
