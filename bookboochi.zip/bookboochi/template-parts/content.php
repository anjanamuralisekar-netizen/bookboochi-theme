<?php
/**
 * Post card used in index/archive/category/search/tag loops.
 *
 * @package Bookboochi
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'bb-card' ); ?>>
	<?php if ( has_post_thumbnail() ) : ?>
		<a class="bb-card-thumb" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
			<?php
			$alt = get_post_meta( get_post_thumbnail_id(), '_wp_attachment_image_alt', true );
			the_post_thumbnail(
				'bookboochi-card',
				array(
					'alt'     => $alt ? $alt : get_the_title(), // wp_get_attachment_image() escapes this internally.
					'loading' => 'lazy',
				)
			);
			?>
		</a>
	<?php endif; ?>

	<div class="bb-card-body">
		<?php
		$categories = get_the_category();
		if ( ! empty( $categories ) ) :
			?>
			<span class="bb-eyebrow"><a href="<?php echo esc_url( get_category_link( $categories[0]->term_id ) ); ?>"><?php echo esc_html( $categories[0]->name ); ?></a></span>
		<?php endif; ?>

		<h2 class="bb-card-title">
			<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
		</h2>

		<?php if ( bookboochi_is_book_review() ) :
			$rating = get_post_meta( get_the_ID(), '_bb_book_rating', true );
			?>
			<p class="bb-card-excerpt">
				<?php
				$book_author = get_post_meta( get_the_ID(), '_bb_book_author', true );
				if ( $book_author ) {
					printf(
						/* translators: %s: book author name */
						esc_html__( 'by %s', 'bookboochi' ),
						esc_html( $book_author )
					);
				}
				?>
			</p>
			<?php if ( '' !== $rating ) : ?>
				<span class="bb-rating" aria-label="<?php echo esc_attr( sprintf( __( 'Rated %s out of 5', 'bookboochi' ), $rating ) ); ?>"><?php echo esc_html( bookboochi_render_stars( $rating ) ); ?></span>
			<?php endif; ?>
		<?php else : ?>
			<p class="bb-card-excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 20, '…' ) ); ?></p>
		<?php endif; ?>

		<?php bookboochi_post_meta(); ?>
	</div>
</article>
