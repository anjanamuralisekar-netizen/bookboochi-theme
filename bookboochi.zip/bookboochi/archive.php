<?php
/**
 * Generic archive template (tags, custom post types, date archives, author).
 *
 * @package Bookboochi
 */

get_header();
?>

<div class="<?php bookboochi_layout_class(); ?>">
	<div>
		<?php bookboochi_breadcrumbs(); ?>

		<header class="bb-page-header">
			<span class="bb-eyebrow"><?php esc_html_e( 'Archive', 'bookboochi' ); ?></span>
			<h1><?php the_archive_title(); ?></h1>
			<?php the_archive_description( '<div class="bb-archive-description">', '</div>' ); ?>
		</header>

		<?php if ( have_posts() ) : ?>
			<div class="bb-post-grid">
				<?php
				while ( have_posts() ) :
					the_post();
					get_template_part( 'template-parts/content' );
				endwhile;
				?>
			</div>
			<?php bookboochi_pagination(); ?>
		<?php else : ?>
			<?php get_template_part( 'template-parts/content', 'none' ); ?>
		<?php endif; ?>
	</div>

	<?php get_sidebar(); ?>
</div>

<?php
get_footer();
