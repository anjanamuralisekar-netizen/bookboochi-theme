<?php
/**
 * Bookboochi theme bootstrap.
 *
 * Loads theme setup, the SEO/AEO/GEO engine, the book-review meta box,
 * the customizer, and template helper functions.
 *
 * @package Bookboochi
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'BOOKBOOCHI_VERSION', '1.0.5' );
define( 'BOOKBOOCHI_DIR', get_template_directory() );
define( 'BOOKBOOCHI_URI', get_template_directory_uri() );

/**
 * Core theme setup: supports, menus, image sizes.
 */
function bookboochi_setup() {
	// Translation ready.
	load_theme_textdomain( 'bookboochi', BOOKBOOCHI_DIR . '/languages' );

	// Let WordPress manage the <title> tag — required for good SEO <head> output.
	add_theme_support( 'title-tag' );

	// Featured images — essential for social sharing / OG image / rich snippets.
	add_theme_support( 'post-thumbnails' );
	set_post_thumbnail_size( 1200, 630, true ); // matches OG image ratio.
	add_image_size( 'bookboochi-card', 640, 400, true );
	add_image_size( 'bookboochi-square', 400, 400, true );

	// Logo & site icon.
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 80,
			'width'       => 240,
			'flex-height' => true,
			'flex-width'  => true,
		)
	);

	// HTML5 semantic markup — search engines and AI crawlers parse this far
	// more reliably than div-soup, and it is a baseline AEO/GEO requirement.
	add_theme_support(
		'html5',
		array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' )
	);

	// Editor / block support.
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'customize-selective-refresh-widgets' );

	// Nav menus.
	register_nav_menus(
		array(
			'primary' => __( 'Primary Menu', 'bookboochi' ),
			'footer'  => __( 'Footer Menu', 'bookboochi' ),
		)
	);

	// Let the excerpt fall back correctly for meta-description generation.
	add_post_type_support( 'page', 'excerpt' );
}
add_action( 'after_setup_theme', 'bookboochi_setup' );

/**
 * Register widget (sidebar) areas.
 */
function bookboochi_widgets_init() {
	register_sidebar(
		array(
			'name'          => __( 'Blog Sidebar', 'bookboochi' ),
			'id'            => 'sidebar-1',
			'description'   => __( 'Appears beside blog posts and archive pages.', 'bookboochi' ),
			'before_widget' => '<div id="%1$s" class="bb-widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h2 class="bb-widget-title">',
			'after_title'   => '</h2>',
		)
	);

	foreach ( array( 1, 2, 3 ) as $i ) {
		register_sidebar(
			array(
				/* translators: %d: footer column number */
				'name'          => sprintf( __( 'Footer Column %d', 'bookboochi' ), $i ),
				'id'            => 'footer-' . $i,
				'description'   => __( 'Widgets in the site footer.', 'bookboochi' ),
				'before_widget' => '<div id="%1$s" class="bb-footer-widget %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<h2 class="bb-footer-widget-title">',
				'after_title'   => '</h2>',
			)
		);
	}
}
add_action( 'widgets_init', 'bookboochi_widgets_init' );

/**
 * Enqueue styles & scripts.
 *
 * Fonts are loaded with preconnect + font-display:swap so text renders
 * immediately with the fallback stack (no invisible-text flash), which
 * protects Core Web Vitals (a ranking + AEO/GEO crawl-budget factor).
 */
function bookboochi_scripts() {
	wp_enqueue_style( 'bookboochi-fonts', bookboochi_fonts_url(), array(), null );
	wp_enqueue_style( 'bookboochi-style', get_stylesheet_uri(), array(), BOOKBOOCHI_VERSION );
	wp_style_add_data( 'bookboochi-style', 'rtl', 'replace' );

	wp_enqueue_script( 'bookboochi-nav', BOOKBOOCHI_URI . '/js/navigation.js', array(), BOOKBOOCHI_VERSION, true );
	wp_enqueue_script( 'bookboochi-toc', BOOKBOOCHI_URI . '/js/toc.js', array(), BOOKBOOCHI_VERSION, true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'bookboochi_scripts' );

/**
 * Google Fonts URL — Playfair Display for headings, Source Serif 4 for
 * body copy, Inter for UI chrome. Single request, display=swap.
 */
function bookboochi_fonts_url() {
	$query_args = array(
		'family'  => implode(
			'&family=',
			array(
				'Playfair+Display:wght@600;700;800',
				'Source+Serif+4:ital,wght@0,400;0,600;1,400',
				'Inter:wght@400;500;600;700',
			)
		),
		'display' => 'swap',
	);
	return add_query_arg( $query_args, 'https://fonts.googleapis.com/css2' );
}

/**
 * Preconnect to the Google Fonts origins for faster first paint.
 */
function bookboochi_resource_hints( $urls, $relation_type ) {
	if ( 'preconnect' === $relation_type ) {
		$urls[] = array(
			'href'        => 'https://fonts.gstatic.com',
			'crossorigin' => '',
		);
		$urls[] = 'https://fonts.googleapis.com';
	}
	return $urls;
}
add_filter( 'wp_resource_hints', 'bookboochi_resource_hints', 10, 2 );

/**
 * Content width for embeds/oEmbeds.
 */
if ( ! isset( $content_width ) ) {
	$content_width = 860;
}

/**
 * Load the rest of the theme's engine.
 */
require BOOKBOOCHI_DIR . '/inc/template-tags.php';
require BOOKBOOCHI_DIR . '/inc/performance.php';
require BOOKBOOCHI_DIR . '/inc/seo.php';
require BOOKBOOCHI_DIR . '/inc/aeo-geo.php';
require BOOKBOOCHI_DIR . '/inc/book-review-meta.php';
require BOOKBOOCHI_DIR . '/inc/customizer.php';
