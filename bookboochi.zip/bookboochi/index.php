<?php
/**
 * Main blog loop (also used as the fallback template).
 *
 * @package Bookboochi
 */

get_header();
?>

<div class="<?php bookboochi_layout_class(); ?>">
	<div>
		<?php bookboochi_breadcrumbs(); ?>

		<?php if ( is_home() && ! is_front_page() ) : ?>
			<header class="bb-page-header">
				<h1 class="bb-eyebrow"><?php esc_html_e( 'Latest', 'bookboochi' ); ?></h1>
			</header>
		<?php endif; ?>

		<?php if ( have_posts() ) : ?>
			<div class="bb-post-grid">
				<?php
				while ( have_posts() ) :
					the_post();
					get_template_part( 'template-parts/content' );
				endwhile;
				?>
			</div>
			<?php bookboochi_pagination(); ?>
		<?php else : ?>
			<?php get_template_part( 'template-parts/content', 'none' ); ?>
		<?php endif; ?>
	</div>

	<?php get_sidebar(); ?>
</div>

<?php
get_footer();
