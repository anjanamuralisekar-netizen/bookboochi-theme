/**
 * Table-of-contents link scroll offset — keeps headings from being hidden
 * under the sticky header when jumping to a #section from the TOC.
 *
 * @package Bookboochi
 */
( function () {
	'use strict';

	var toc = document.querySelector( '.bb-toc' );
	var header = document.querySelector( '.bb-site-header' );

	if ( ! toc || ! header ) {
		return;
	}

	toc.addEventListener( 'click', function ( e ) {
		var link = e.target.closest( 'a[href^="#"]' );
		if ( ! link ) {
			return;
		}
		var target = document.getElementById( link.getAttribute( 'href' ).slice( 1 ) );
		if ( ! target ) {
			return;
		}
		e.preventDefault();
		var offset = header.offsetHeight + 16;
		var top = target.getBoundingClientRect().top + window.pageYOffset - offset;
		window.scrollTo( { top: top, behavior: 'smooth' } );
		history.pushState( null, '', link.getAttribute( 'href' ) );
		target.setAttribute( 'tabindex', '-1' );
		target.focus( { preventScroll: true } );
	} );
} )();
