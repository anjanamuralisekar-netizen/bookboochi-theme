/**
 * Mobile menu toggle + touch-friendly dropdown handling for items with
 * a sub-menu (e.g. a "Genre" parent listing every genre underneath it).
 *
 * @package Bookboochi
 */
( function () {
	'use strict';

	var toggle = document.querySelector( '.bb-menu-toggle' );
	var menu = document.getElementById( 'bb-primary-menu' );

	if ( toggle && menu ) {
		toggle.addEventListener( 'click', function () {
			var isOpen = menu.classList.toggle( 'is-open' );
			toggle.setAttribute( 'aria-expanded', isOpen ? 'true' : 'false' );
		} );
	}

	if ( ! menu ) {
		return;
	}

	// Dropdowns already open on :hover/:focus-within via CSS for mouse
	// and keyboard users. Touch devices have no hover state, so a parent
	// item's link would otherwise navigate away immediately without ever
	// revealing its dropdown. This makes the FIRST tap open the dropdown
	// instead of following the link; a second tap on the same link (or
	// tapping outside) proceeds normally.
	var parents = menu.querySelectorAll( '.menu-item-has-children' );
	var noHover = window.matchMedia && window.matchMedia( '(hover: none)' ).matches;

	if ( noHover ) {
		parents.forEach( function ( parent ) {
			var link = parent.querySelector( ':scope > a' );
			if ( ! link ) {
				return;
			}
			link.addEventListener( 'click', function ( e ) {
				if ( ! parent.classList.contains( 'bb-submenu-open' ) ) {
					e.preventDefault();
					parents.forEach( function ( other ) {
						if ( other !== parent ) {
							other.classList.remove( 'bb-submenu-open' );
						}
					} );
					parent.classList.add( 'bb-submenu-open' );
				}
			} );
		} );

		document.addEventListener( 'click', function ( e ) {
			if ( ! menu.contains( e.target ) ) {
				parents.forEach( function ( parent ) {
					parent.classList.remove( 'bb-submenu-open' );
				} );
			}
		} );
	}

	document.addEventListener( 'keydown', function ( e ) {
		if ( 'Escape' === e.key ) {
			parents.forEach( function ( parent ) {
				parent.classList.remove( 'bb-submenu-open' );
			} );
		}
	} );
} )();
