<?php
/**
 * Header template: opens <html>, outputs <head>, site branding & nav.
 *
 * @package Bookboochi
 */
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="bb-skip-link" href="#bb-content"><?php esc_html_e( 'Skip to content', 'bookboochi' ); ?></a>

<header class="bb-site-header">
	<div class="bb-container bb-header-inner">
		<div class="bb-site-branding">
			<?php
			if ( has_custom_logo() ) {
				the_custom_logo();
			}
			?>
			<div>
				<?php if ( is_front_page() && is_home() ) : ?>
					<h1 class="bb-site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
				<?php else : ?>
					<p class="bb-site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></p>
				<?php endif; ?>
				<?php
				$description = get_bloginfo( 'description', 'display' );
				if ( $description ) :
					?>
					<p class="bb-site-description"><?php echo esc_html( $description ); ?></p>
				<?php endif; ?>
			</div>
		</div>

		<button class="bb-menu-toggle" aria-controls="bb-primary-menu" aria-expanded="false">
			<?php esc_html_e( 'Menu', 'bookboochi' ); ?>
		</button>

		<nav class="bb-primary-nav" id="bb-primary-menu" aria-label="<?php esc_attr_e( 'Primary', 'bookboochi' ); ?>">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'primary',
					'container'      => false,
					'fallback_cb'    => 'bookboochi_default_menu',
				)
			);
			?>
		</nav>

		<form class="bb-header-search bb-search-form" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
			<label class="screen-reader-text" for="bb-search-field"><?php esc_html_e( 'Search for:', 'bookboochi' ); ?></label>
			<input type="search" id="bb-search-field" name="s" placeholder="<?php esc_attr_e( 'Search books…', 'bookboochi' ); ?>" value="<?php echo esc_attr( get_search_query() ); ?>" />
		</form>
	</div>
</header>

<?php
/**
 * Fallback menu when no "primary" menu is assigned in Appearance → Menus.
 */
function bookboochi_default_menu() {
	echo '<ul>';
	wp_list_pages(
		array(
			'title_li' => '',
			'depth'    => 1,
		)
	);
	echo '</ul>';
}
?>

<main id="bb-content" class="bb-main">
	<div class="bb-container">
