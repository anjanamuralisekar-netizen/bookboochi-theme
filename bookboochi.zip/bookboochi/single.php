<?php
/**
 * Single post template — the primary template for book reviews / articles.
 *
 * @package Bookboochi
 */

get_header();
?>

<div class="<?php bookboochi_layout_class(); ?>">
	<div>
		<?php
		while ( have_posts() ) :
			the_post();
			?>
			<article id="post-<?php the_ID(); ?>" <?php post_class( 'bb-single' ); ?>>

				<?php bookboochi_breadcrumbs(); ?>

				<header class="bb-post-header">
					<?php
					$categories = get_the_category();
					if ( ! empty( $categories ) ) :
						?>
						<span class="bb-eyebrow"><a href="<?php echo esc_url( get_category_link( $categories[0]->term_id ) ); ?>"><?php echo esc_html( $categories[0]->name ); ?></a></span>
					<?php endif; ?>

					<h1 class="bb-post-title"><?php the_title(); ?></h1>

					<?php bookboochi_post_meta(); ?>
				</header>

				<?php bookboochi_featured_image( 'large' ); ?>

				<?php get_template_part( 'template-parts/content', 'book-review' ); ?>

				<div class="bb-entry-content">
					<?php
					the_content();

					wp_link_pages(
						array(
							'before' => '<nav class="bb-pagination page-links" aria-label="' . esc_attr__( 'Page', 'bookboochi' ) . '"><span>' . esc_html__( 'Pages:', 'bookboochi' ) . '</span>',
							'after'  => '</nav>',
						)
					);
					?>
				</div>

				<?php get_template_part( 'template-parts/faq' ); ?>

				<?php
				$tags = get_the_tags();
				if ( $tags ) :
					?>
					<div class="bb-tags">
						<?php foreach ( $tags as $tag ) : ?>
							<a href="<?php echo esc_url( get_tag_link( $tag ) ); ?>">#<?php echo esc_html( $tag->name ); ?></a>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>

				<?php bookboochi_author_box(); ?>

				<?php bookboochi_post_navigation(); ?>

			</article>

			<?php
			if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif;
		endwhile;
		?>
	</div>

	<?php get_sidebar(); ?>
</div>

<?php
get_footer();
