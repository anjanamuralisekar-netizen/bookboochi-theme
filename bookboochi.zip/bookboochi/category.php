<?php
/**
 * Category archive template.
 *
 * @package Bookboochi
 */

get_header();
?>

<div class="<?php bookboochi_layout_class(); ?>">
	<div>
		<?php bookboochi_breadcrumbs(); ?>

		<header class="bb-page-header">
			<span class="bb-eyebrow"><?php esc_html_e( 'Category', 'bookboochi' ); ?></span>
			<h1><?php single_cat_title(); ?></h1>
			<?php
			$description = category_description();
			if ( $description ) :
				?>
				<div class="bb-archive-description"><?php echo wp_kses_post( $description ); ?></div>
			<?php endif; ?>
		</header>

		<?php if ( have_posts() ) : ?>
			<div class="bb-post-grid">
				<?php
				while ( have_posts() ) :
					the_post();
					get_template_part( 'template-parts/content' );
				endwhile;
				?>
			</div>
			<?php bookboochi_pagination(); ?>
		<?php else : ?>
			<?php get_template_part( 'template-parts/content', 'none' ); ?>
		<?php endif; ?>
	</div>

	<?php get_sidebar(); ?>
</div>

<?php
get_footer();
