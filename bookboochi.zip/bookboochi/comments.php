<?php
/**
 * Comments template.
 *
 * @package Bookboochi
 */

if ( post_password_required() ) {
	return;
}
?>

<div id="comments" class="bb-comments">

	<?php if ( have_comments() ) : ?>
		<h2 class="bb-comments-title">
			<?php
			$count = get_comments_number();
			printf(
				/* translators: %s: number of comments */
				esc_html( _n( '%s thought', '%s thoughts', $count, 'bookboochi' ) ),
				esc_html( number_format_i18n( $count ) )
			);
			?>
		</h2>

		<ol class="comment-list">
			<?php
			wp_list_comments(
				array(
					'style'       => 'ol',
					'short_ping'  => true,
					'avatar_size' => 48,
				)
			);
			?>
		</ol>

		<?php
		the_comments_pagination(
			array(
				'prev_text' => __( '&larr; Older comments', 'bookboochi' ),
				'next_text' => __( 'Newer comments &rarr;', 'bookboochi' ),
			)
		);
		?>
	<?php endif; ?>

	<?php if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) : ?>
		<p class="no-comments"><?php esc_html_e( 'Comments are closed.', 'bookboochi' ); ?></p>
	<?php endif; ?>

	<?php
	comment_form(
		array(
			'class_submit' => 'bb-btn',
			'title_reply'  => __( 'Leave a comment', 'bookboochi' ),
		)
	);
	?>
</div>
