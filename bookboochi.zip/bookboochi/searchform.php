<?php
/**
 * Standalone search form (get_search_form() template).
 *
 * @package Bookboochi
 */
?>
<form role="search" method="get" class="bb-search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label class="screen-reader-text" for="bb-search-field-standalone"><?php esc_html_e( 'Search for:', 'bookboochi' ); ?></label>
	<input type="search" id="bb-search-field-standalone" name="s" placeholder="<?php esc_attr_e( 'Search books, genres, authors…', 'bookboochi' ); ?>" value="<?php echo esc_attr( get_search_query() ); ?>" />
	<button type="submit" class="bb-btn"><?php esc_html_e( 'Search', 'bookboochi' ); ?></button>
</form>
