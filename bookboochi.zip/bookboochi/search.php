<?php
/**
 * Search results template.
 *
 * @package Bookboochi
 */

get_header();
?>

<div class="<?php bookboochi_layout_class(); ?>">
	<div>
		<header class="bb-page-header">
			<span class="bb-eyebrow"><?php esc_html_e( 'Search results', 'bookboochi' ); ?></span>
			<h1>
				<?php
				printf(
					/* translators: %s: search query */
					esc_html__( 'Results for: %s', 'bookboochi' ),
					'<em>' . esc_html( get_search_query() ) . '</em>'
				);
				?>
			</h1>
		</header>

		<?php if ( have_posts() ) : ?>
			<div class="bb-post-grid">
				<?php
				while ( have_posts() ) :
					the_post();
					get_template_part( 'template-parts/content' );
				endwhile;
				?>
			</div>
			<?php bookboochi_pagination(); ?>
		<?php else : ?>
			<?php get_template_part( 'template-parts/content', 'none' ); ?>
		<?php endif; ?>
	</div>

	<?php get_sidebar(); ?>
</div>

<?php
get_footer();
