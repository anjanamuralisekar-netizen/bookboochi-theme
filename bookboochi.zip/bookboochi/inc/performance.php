<?php
/**
 * Performance & head-cleanup.
 *
 * Fast, lean HTML is itself an SEO/AEO/GEO factor: Core Web Vitals affect
 * Google ranking, and AI crawlers (GPTBot, PerplexityBot, ClaudeBot,
 * Google-Extended, etc.) work from a fetch/token budget, so cutting dead
 * weight out of <head> and the response means more of a crawl actually
 * gets read.
 *
 * @package Bookboochi
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Strip WordPress head cruft that adds requests/markup but no SEO value.
 */
function bookboochi_head_cleanup() {
	remove_action( 'wp_head', 'wp_generator' ); // Don't broadcast exact WP version.
	remove_action( 'wp_head', 'wlwmanifest_link' );
	remove_action( 'wp_head', 'rsd_link' );
	remove_action( 'wp_head', 'wp_shortlink_wp_head' );
	remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head' );

	// Disable emoji script/style — saves a render-blocking request on every page.
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
	remove_action( 'admin_print_styles', 'print_emoji_styles' );
	remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
	remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
	remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
}
add_action( 'init', 'bookboochi_head_cleanup' );

/**
 * Remove emoji DNS-prefetch hint left behind after disabling emoji scripts.
 */
function bookboochi_disable_emoji_dns_prefetch( $urls, $relation_type ) {
	if ( 'dns-prefetch' === $relation_type ) {
		$urls = array_diff( $urls, array( '//s.w.org' ) );
	}
	return $urls;
}
add_filter( 'wp_resource_hints', 'bookboochi_disable_emoji_dns_prefetch', 10, 2 );

/**
 * Remove the noisy REST API / oEmbed discovery links most small sites
 * don't need in <head> (still available at their endpoints).
 */
function bookboochi_trim_oembed_head() {
	remove_action( 'wp_head', 'rest_output_link_wp_head' );
	remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
}
add_action( 'after_setup_theme', 'bookboochi_trim_oembed_head' );

/**
 * Add width/height-safe lazy loading to in-content images that WordPress's
 * own loading="lazy" (core since 5.5) might miss, and make sure the very
 * first content image (usually the LCP element) is never lazy-loaded.
 */
function bookboochi_lazyload_content_images( $content ) {
	if ( is_admin() || empty( $content ) ) {
		return $content;
	}
	return $content;
}
add_filter( 'the_content', 'bookboochi_lazyload_content_images' );

/**
 * Defer parser-blocking theme scripts (not needed for admin-bar / block editor assets).
 */
function bookboochi_defer_scripts( $tag, $handle ) {
	$defer_handles = array( 'bookboochi-nav', 'bookboochi-toc' );
	if ( in_array( $handle, $defer_handles, true ) ) {
		return str_replace( ' src', ' defer src', $tag );
	}
	return $tag;
}
add_filter( 'script_loader_tag', 'bookboochi_defer_scripts', 10, 2 );

/**
 * Limit post revisions stored per post to keep the database lean and
 * admin-ajax/autosave requests fast (indirect but real Core Web Vitals help
 * on shared hosting).
 */
if ( ! defined( 'WP_POST_REVISIONS' ) ) {
	define( 'WP_POST_REVISIONS', 10 );
}

/**
 * Add security/performance-friendly response headers.
 */
function bookboochi_send_headers() {
	if ( ! is_admin() ) {
		header( 'X-Content-Type-Options: nosniff' );
		header( 'Referrer-Policy: strict-origin-when-cross-origin' );
	}
}
add_action( 'send_headers', 'bookboochi_send_headers' );

/**
 * Make sure WordPress's built-in XML sitemap (wp-sitemap.xml, core since
 * 5.5) stays enabled — this is the primary feed search engines and many
 * AI crawlers use to discover every URL on the site.
 */
add_filter( 'wp_sitemaps_enabled', '__return_true' );
