<?php
/**
 * Reusable template helper functions.
 *
 * @package Bookboochi
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Output post meta (date, author, category, reading time) for cards & singles.
 */
function bookboochi_posted_on() {
	$time_string = '<time class="published" datetime="%1$s">%2$s</time>';
	if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
		$time_string = '<time class="published" datetime="%1$s">%2$s</time><time class="updated screen-reader-text" datetime="%3$s">%4$s</time>';
	}

	$time_html = sprintf(
		$time_string,
		esc_attr( get_the_date( DATE_W3C ) ),
		esc_html( get_the_date() ),
		esc_attr( get_the_modified_date( DATE_W3C ) ),
		esc_html( get_the_modified_date() )
	);

	printf(
		'<span class="bb-meta-date">%s</span>',
		$time_html // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	);
}

/**
 * Output the author link.
 */
function bookboochi_posted_by() {
	printf(
		'<span class="bb-meta-author">%1$s <a href="%2$s" rel="author">%3$s</a></span>',
		esc_html__( 'by', 'bookboochi' ),
		esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
		esc_html( get_the_author() )
	);
}

/**
 * Estimated reading time — a small but real AEO/UX signal (helps users and
 * assistants judge content depth at a glance).
 */
function bookboochi_reading_time() {
	$content = get_post_field( 'post_content', get_the_ID() );
	$word_count = str_word_count( wp_strip_all_tags( $content ) );
	$minutes = max( 1, (int) ceil( $word_count / 200 ) );

	printf(
		'<span class="bb-meta-reading-time">%s</span>',
		/* translators: %d: number of minutes */
		esc_html( sprintf( _n( '%d min read', '%d min read', $minutes, 'bookboochi' ), $minutes ) )
	);
}

/**
 * Full post meta row used in cards and single posts.
 */
function bookboochi_post_meta( $show_author = true ) {
	echo '<div class="bb-post-meta">';
	bookboochi_posted_on();
	if ( $show_author ) {
		bookboochi_posted_by();
	}
	bookboochi_reading_time();
	echo '</div>';
}

/**
 * Breadcrumb trail with visible markup (the matching JSON-LD BreadcrumbList
 * is emitted separately in inc/aeo-geo.php so both humans and machines get
 * the same trail).
 */
function bookboochi_breadcrumbs() {
	if ( is_front_page() ) {
		return;
	}

	$crumbs = bookboochi_get_breadcrumb_trail();
	if ( count( $crumbs ) < 2 ) {
		return;
	}

	echo '<nav class="bb-breadcrumbs" aria-label="' . esc_attr__( 'Breadcrumb', 'bookboochi' ) . '">';
	$last = count( $crumbs ) - 1;
	foreach ( $crumbs as $i => $crumb ) {
		if ( $i > 0 ) {
			echo '<span class="sep" aria-hidden="true">/</span>';
		}
		if ( $i === $last ) {
			echo '<span aria-current="page">' . esc_html( $crumb['title'] ) . '</span>';
		} else {
			echo '<a href="' . esc_url( $crumb['url'] ) . '">' . esc_html( $crumb['title'] ) . '</a>';
		}
	}
	echo '</nav>';
}

/**
 * Build the breadcrumb trail as an array of ['title' => ..., 'url' => ...].
 * Shared between the visible breadcrumbs and the JSON-LD BreadcrumbList.
 */
function bookboochi_get_breadcrumb_trail() {
	$crumbs = array();
	$crumbs[] = array(
		'title' => __( 'Home', 'bookboochi' ),
		'url'   => home_url( '/' ),
	);

	if ( is_singular( 'post' ) ) {
		$categories = get_the_category();
		if ( ! empty( $categories ) ) {
			$cat = $categories[0];
			$crumbs[] = array(
				'title' => $cat->name,
				'url'   => get_category_link( $cat->term_id ),
			);
		}
		$crumbs[] = array(
			'title' => get_the_title(),
			'url'   => get_permalink(),
		);
	} elseif ( is_page() ) {
		global $post;
		$ancestors = array_reverse( get_post_ancestors( $post ) );
		foreach ( $ancestors as $ancestor_id ) {
			$crumbs[] = array(
				'title' => get_the_title( $ancestor_id ),
				'url'   => get_permalink( $ancestor_id ),
			);
		}
		$crumbs[] = array(
			'title' => get_the_title(),
			'url'   => get_permalink(),
		);
	} elseif ( is_category() ) {
		$crumbs[] = array(
			'title' => single_cat_title( '', false ),
			'url'   => get_category_link( get_queried_object_id() ),
		);
	} elseif ( is_tag() ) {
		$crumbs[] = array(
			'title' => single_tag_title( '', false ),
			'url'   => get_tag_link( get_queried_object_id() ),
		);
	} elseif ( is_tax() ) {
		// Any custom taxonomy archive (e.g. the Bookboochi Library plugin's
		// Book Genre / Book Author pages). single_term_title() returns the
		// plain term name, same as the category/tag branches above — unlike
		// get_the_archive_title() below, it contains no markup, so it's
		// safe to esc_html() when the breadcrumb is printed and safe to
		// drop straight into the JSON-LD BreadcrumbList as plain text.
		$crumbs[] = array(
			'title' => single_term_title( '', false ),
			'url'   => get_term_link( get_queried_object() ),
		);
	} elseif ( is_search() ) {
		$crumbs[] = array(
			'title' => sprintf( __( 'Search results for &#8220;%s&#8221;', 'bookboochi' ), get_search_query() ),
			'url'   => get_search_link(),
		);
	} elseif ( is_author() ) {
		$crumbs[] = array(
			'title' => get_the_author_meta( 'display_name', (int) get_query_var( 'author' ) ),
			'url'   => '',
		);
	} elseif ( is_archive() ) {
		// Fallback for any other archive type (date archives, a future
		// custom post type, etc). get_the_archive_title() can return real
		// HTML (WordPress core wraps parts of it in markup for some
		// archive types) — strip it to plain text so it's safe wherever
		// this trail is displayed or embedded in JSON-LD.
		$crumbs[] = array(
			'title' => wp_strip_all_tags( get_the_archive_title() ),
			'url'   => '',
		);
	} elseif ( is_404() ) {
		$crumbs[] = array(
			'title' => __( 'Page not found', 'bookboochi' ),
			'url'   => '',
		);
	}

	return $crumbs;
}

/**
 * Author bio box shown at the end of every post — a direct E-E-A-T
 * (Experience, Expertise, Authoritativeness, Trust) signal that both
 * classic search ranking systems and generative engines weigh heavily
 * when deciding whether to surface or cite a page.
 */
function bookboochi_author_box() {
	$author_id  = get_the_author_meta( 'ID' );
	$bio        = get_the_author_meta( 'description' );
	$display    = get_the_author_meta( 'display_name' );
	$website    = get_the_author_meta( 'user_url' );

	if ( empty( $bio ) ) {
		return;
	}
	?>
	<div class="bb-author-box">
		<?php echo get_avatar( $author_id, 128 ); ?>
		<div>
			<h2><?php esc_html_e( 'Written by', 'bookboochi' ); ?></h2>
			<p class="bb-author-name"><?php echo esc_html( $display ); ?></p>
			<p class="bb-author-bio-text"><?php echo esc_html( $bio ); ?></p>
			<div class="bb-author-links">
				<a href="<?php echo esc_url( get_author_posts_url( $author_id ) ); ?>">
					<?php esc_html_e( 'More posts', 'bookboochi' ); ?>
				</a>
				<?php if ( $website ) : ?>
					<a href="<?php echo esc_url( $website ); ?>" rel="me nofollow">
						<?php esc_html_e( 'Website', 'bookboochi' ); ?>
					</a>
				<?php endif; ?>
			</div>
		</div>
	</div>
	<?php
}

/**
 * Custom pagination markup shared by index/archive/category/search.
 */
function bookboochi_pagination() {
	$pagination = paginate_links(
		array(
			'prev_text' => __( '&larr; Newer', 'bookboochi' ),
			'next_text' => __( 'Older &rarr;', 'bookboochi' ),
			'type'      => 'array',
		)
	);

	if ( empty( $pagination ) ) {
		return;
	}

	echo '<nav class="bb-pagination" aria-label="' . esc_attr__( 'Posts navigation', 'bookboochi' ) . '">';
	foreach ( $pagination as $link ) {
		echo wp_kses_post( $link );
	}
	echo '</nav>';
}

/**
 * Prev/next single post navigation.
 */
function bookboochi_post_navigation() {
	$prev = get_previous_post();
	$next = get_next_post();

	if ( ! $prev && ! $next ) {
		return;
	}
	?>
	<nav class="bb-post-nav" aria-label="<?php esc_attr_e( 'Post navigation', 'bookboochi' ); ?>">
		<?php if ( $prev ) : ?>
			<a class="bb-nav-prev" href="<?php echo esc_url( get_permalink( $prev ) ); ?>">
				<span><?php esc_html_e( 'Previous', 'bookboochi' ); ?></span>
				<?php echo esc_html( get_the_title( $prev ) ); ?>
			</a>
		<?php else : ?>
			<span></span>
		<?php endif; ?>
		<?php if ( $next ) : ?>
			<a class="bb-nav-next" href="<?php echo esc_url( get_permalink( $next ) ); ?>">
				<span><?php esc_html_e( 'Next', 'bookboochi' ); ?></span>
				<?php echo esc_html( get_the_title( $next ) ); ?>
			</a>
		<?php endif; ?>
	</nav>
	<?php
}

/**
 * Link to a taxonomy's terms on a post if they exist (e.g. the Bookboochi
 * Library plugin's Author/Genre taxonomies), otherwise fall back to a
 * plain-text value. Used by template-parts/content-book-review.php so the
 * theme's own "Book at a glance" box gains clickable Author/Genre links
 * wherever that plugin's fields are filled in, without requiring it.
 */
function bookboochi_linked_terms_or_text( $post_id, $taxonomy, $fallback_text ) {
	if ( ! taxonomy_exists( $taxonomy ) ) {
		return $fallback_text ? esc_html( $fallback_text ) : '';
	}
	$terms = get_the_terms( $post_id, $taxonomy );
	if ( empty( $terms ) || is_wp_error( $terms ) ) {
		return $fallback_text ? esc_html( $fallback_text ) : '';
	}
	$links = array();
	foreach ( $terms as $term ) {
		$links[] = sprintf( '<a href="%1$s">%2$s</a>', esc_url( get_term_link( $term ) ), esc_html( $term->name ) );
	}
	return implode( ', ', $links );
}

/**
 * CSS class for the two-column layout wrapper — collapses to a single
 * column automatically when the sidebar has no widgets in it.
 */
function bookboochi_layout_class() {
	echo is_active_sidebar( 'sidebar-1' ) ? 'bb-layout' : 'bb-layout bb-no-sidebar';
}

/**
 * Render the featured image with descriptive alt fallback. Google's image
 * & AI-overview systems lean heavily on alt text, so we always guarantee
 * one instead of leaving it blank when an editor forgets.
 */
function bookboochi_featured_image( $size = 'large' ) {
	if ( ! has_post_thumbnail() ) {
		return;
	}

	$alt = get_post_meta( get_post_thumbnail_id(), '_wp_attachment_image_alt', true );
	if ( empty( $alt ) ) {
		$alt = get_the_title();
	}

	echo '<div class="bb-featured-image">';
	the_post_thumbnail(
		$size,
		array(
			'alt'      => $alt, // wp_get_attachment_image() escapes this internally — don't double-escape.
			'loading'  => 'eager',
			'fetchpriority' => 'high',
		)
	);
	echo '</div>';
}
