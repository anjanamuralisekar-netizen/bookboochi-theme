<?php
/**
 * Built-in SEO engine.
 *
 * Bookboochi ships its own lightweight meta title/description, canonical,
 * Open Graph, Twitter Card and robots-meta output so the theme is fully
 * SEO-functional with zero plugins. If the site later installs Yoast SEO,
 * Rank Math, or a similar plugin, this theme automatically steps aside so
 * tags are never duplicated.
 *
 * @package Bookboochi
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Detect a well-known SEO plugin so we don't double up on meta tags.
 */
function bookboochi_seo_plugin_active() {
	return defined( 'WPSEO_VERSION' )        // Yoast SEO.
		|| class_exists( 'RankMath' )         // Rank Math.
		|| defined( 'AIOSEO_VERSION' )        // All in One SEO.
		|| class_exists( 'The_SEO_Framework' ); // SEOPress / SEO Framework.
}

/* -----------------------------------------------------------------------
 * Meta box: per-post SEO title / meta description / social image override.
 * Used as the fallback source (and always used for JSON-LD) when no SEO
 * plugin is active.
 * -------------------------------------------------------------------- */

function bookboochi_seo_meta_box() {
	add_meta_box(
		'bookboochi_seo',
		__( 'Bookboochi SEO / Social', 'bookboochi' ),
		'bookboochi_seo_meta_box_html',
		array( 'post', 'page' ),
		'normal',
		'high'
	);
}
add_action( 'add_meta_boxes', 'bookboochi_seo_meta_box' );

function bookboochi_seo_meta_box_html( $post ) {
	wp_nonce_field( 'bookboochi_seo_save', 'bookboochi_seo_nonce' );
	$title = get_post_meta( $post->ID, '_bookboochi_seo_title', true );
	$desc  = get_post_meta( $post->ID, '_bookboochi_seo_description', true );
	$faq   = get_post_meta( $post->ID, '_bookboochi_faq', true );
	?>
	<p>
		<label for="bookboochi_seo_title"><strong><?php esc_html_e( 'SEO title (used in browser tab, Google result, and social cards)', 'bookboochi' ); ?></strong></label><br />
		<input type="text" id="bookboochi_seo_title" name="bookboochi_seo_title" value="<?php echo esc_attr( $title ); ?>" style="width:100%;" maxlength="70" placeholder="<?php echo esc_attr( get_the_title( $post ) ); ?>" />
		<small><?php esc_html_e( 'Recommended: under 60 characters. Leave blank to use the post title.', 'bookboochi' ); ?></small>
	</p>
	<p>
		<label for="bookboochi_seo_description"><strong><?php esc_html_e( 'Meta description', 'bookboochi' ); ?></strong></label><br />
		<textarea id="bookboochi_seo_description" name="bookboochi_seo_description" style="width:100%;" rows="3" maxlength="160"><?php echo esc_textarea( $desc ); ?></textarea>
		<small><?php esc_html_e( 'Recommended: under 155 characters. This also seeds the Open Graph / Twitter description and the JSON-LD "description" field that answer engines read. Leave blank to auto-generate from the excerpt.', 'bookboochi' ); ?></small>
	</p>
	<p>
		<label for="bookboochi_faq"><strong><?php esc_html_e( 'FAQ block (optional, powers AEO "answer" rich results)', 'bookboochi' ); ?></strong></label><br />
		<textarea id="bookboochi_faq" name="bookboochi_faq" style="width:100%;" rows="6" placeholder="Q: Is this book good for beginners?&#10;A: Yes, it&#39;s an accessible entry point...&#10;&#10;Q: How long is it?&#10;A: 320 pages."><?php echo esc_textarea( $faq ); ?></textarea>
		<small><?php esc_html_e( 'One question per "Q:" line, one answer per "A:" line. This renders as an on-page FAQ section and a matching FAQPage schema block that AI assistants and Google can quote directly.', 'bookboochi' ); ?></small>
	</p>
	<?php
}

function bookboochi_seo_meta_box_save( $post_id ) {
	if ( ! isset( $_POST['bookboochi_seo_nonce'] ) || ! wp_verify_nonce( $_POST['bookboochi_seo_nonce'], 'bookboochi_seo_save' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	if ( isset( $_POST['bookboochi_seo_title'] ) ) {
		update_post_meta( $post_id, '_bookboochi_seo_title', sanitize_text_field( wp_unslash( $_POST['bookboochi_seo_title'] ) ) );
	}
	if ( isset( $_POST['bookboochi_seo_description'] ) ) {
		update_post_meta( $post_id, '_bookboochi_seo_description', sanitize_textarea_field( wp_unslash( $_POST['bookboochi_seo_description'] ) ) );
	}
	if ( isset( $_POST['bookboochi_faq'] ) ) {
		update_post_meta( $post_id, '_bookboochi_faq', sanitize_textarea_field( wp_unslash( $_POST['bookboochi_faq'] ) ) );
	}
}
add_action( 'save_post', 'bookboochi_seo_meta_box_save' );

/* -----------------------------------------------------------------------
 * Helpers to resolve the effective title / description for the current view.
 * -------------------------------------------------------------------- */

function bookboochi_get_seo_title() {
	if ( is_singular() ) {
		$custom = get_post_meta( get_the_ID(), '_bookboochi_seo_title', true );
		if ( ! empty( $custom ) ) {
			return $custom;
		}
		return get_the_title();
	}
	if ( is_home() || is_front_page() ) {
		$tagline = get_bloginfo( 'description' );
		return get_bloginfo( 'name' ) . ( $tagline ? ' — ' . $tagline : '' );
	}
	if ( is_category() ) {
		return single_cat_title( '', false ) . ' — ' . get_bloginfo( 'name' );
	}
	if ( is_tag() ) {
		return single_tag_title( '', false ) . ' — ' . get_bloginfo( 'name' );
	}
	if ( is_author() ) {
		return get_the_author_meta( 'display_name', (int) get_query_var( 'author' ) ) . ' — ' . get_bloginfo( 'name' );
	}
	if ( is_search() ) {
		return sprintf( __( 'Search results for "%s"', 'bookboochi' ), get_search_query() ) . ' — ' . get_bloginfo( 'name' );
	}
	if ( is_404() ) {
		return __( 'Page not found', 'bookboochi' ) . ' — ' . get_bloginfo( 'name' );
	}
	return wp_get_document_title();
}

function bookboochi_get_seo_description() {
	if ( is_singular() ) {
		$custom = get_post_meta( get_the_ID(), '_bookboochi_seo_description', true );
		if ( ! empty( $custom ) ) {
			return $custom;
		}
		$post = get_queried_object();
		if ( $post instanceof WP_Post ) {
			$excerpt = has_excerpt( $post ) ? get_the_excerpt( $post ) : wp_strip_all_tags( $post->post_content );
			return wp_trim_words( $excerpt, 30, '…' );
		}
	}
	if ( is_category() || is_tag() ) {
		$desc = term_description();
		if ( $desc ) {
			return wp_trim_words( wp_strip_all_tags( $desc ), 30, '…' );
		}
	}
	$tagline = get_bloginfo( 'description' );
	return $tagline ? $tagline : get_bloginfo( 'name' );
}

/**
 * Pick the best available social/OG image for the current view.
 */
function bookboochi_get_seo_image() {
	if ( is_singular() && has_post_thumbnail() ) {
		$img = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full' );
		if ( $img ) {
			return $img[0];
		}
	}
	$custom_logo_id = get_theme_mod( 'custom_logo' );
	if ( $custom_logo_id ) {
		$img = wp_get_attachment_image_src( $custom_logo_id, 'full' );
		if ( $img ) {
			return $img[0];
		}
	}
	return '';
}

/* -----------------------------------------------------------------------
 * Output <head> tags (skipped entirely if a real SEO plugin is active).
 * -------------------------------------------------------------------- */

function bookboochi_output_meta_tags() {
	if ( bookboochi_seo_plugin_active() ) {
		return;
	}

	$title       = bookboochi_get_seo_title();
	$description = bookboochi_get_seo_description();
	$image       = bookboochi_get_seo_image();
	$url         = is_singular() ? get_permalink() : bookboochi_get_current_url();
	$site_name   = get_bloginfo( 'name' );

	echo "\n<!-- Bookboochi SEO -->\n";

	if ( $description ) {
		printf( '<meta name="description" content="%s" />' . "\n", esc_attr( $description ) );
	}

	// Canonical — critical for avoiding duplicate-content dilution, and it
	// is the URL generative engines cite back to the user.
	printf( '<link rel="canonical" href="%s" />' . "\n", esc_url( $url ) );

	// Robots directive.
	if ( is_search() || is_404() ) {
		echo '<meta name="robots" content="noindex,follow" />' . "\n";
	} elseif ( ! is_paged() ) {
		echo '<meta name="robots" content="index,follow,max-image-preview:large" />' . "\n";
	} else {
		echo '<meta name="robots" content="noindex,follow" />' . "\n";
	}

	// Open Graph.
	printf( '<meta property="og:locale" content="%s" />' . "\n", esc_attr( get_locale() ) );
	printf( '<meta property="og:type" content="%s" />' . "\n", is_singular( 'post' ) ? 'article' : 'website' );
	printf( '<meta property="og:title" content="%s" />' . "\n", esc_attr( $title ) );
	if ( $description ) {
		printf( '<meta property="og:description" content="%s" />' . "\n", esc_attr( $description ) );
	}
	printf( '<meta property="og:url" content="%s" />' . "\n", esc_url( $url ) );
	printf( '<meta property="og:site_name" content="%s" />' . "\n", esc_attr( $site_name ) );
	if ( $image ) {
		printf( '<meta property="og:image" content="%s" />' . "\n", esc_url( $image ) );
		echo '<meta property="og:image:width" content="1200" />' . "\n";
		echo '<meta property="og:image:height" content="630" />' . "\n";
	}

	if ( is_singular( 'post' ) ) {
		printf( '<meta property="article:published_time" content="%s" />' . "\n", esc_attr( get_the_date( DATE_W3C ) ) );
		printf( '<meta property="article:modified_time" content="%s" />' . "\n", esc_attr( get_the_modified_date( DATE_W3C ) ) );
		foreach ( get_the_category() as $cat ) {
			printf( '<meta property="article:section" content="%s" />' . "\n", esc_attr( $cat->name ) );
		}
	}

	// Twitter Card.
	echo '<meta name="twitter:card" content="summary_large_image" />' . "\n";
	printf( '<meta name="twitter:title" content="%s" />' . "\n", esc_attr( $title ) );
	if ( $description ) {
		printf( '<meta name="twitter:description" content="%s" />' . "\n", esc_attr( $description ) );
	}
	if ( $image ) {
		printf( '<meta name="twitter:image" content="%s" />' . "\n", esc_url( $image ) );
	}

	echo "<!-- /Bookboochi SEO -->\n";
}
add_action( 'wp_head', 'bookboochi_output_meta_tags', 1 );

/**
 * Filter wp_title/document title so the fallback matches our SEO title
 * when no SEO plugin is present.
 */
function bookboochi_document_title_parts( $title_parts ) {
	if ( bookboochi_seo_plugin_active() ) {
		return $title_parts;
	}
	if ( is_singular() ) {
		$custom = get_post_meta( get_the_ID(), '_bookboochi_seo_title', true );
		if ( ! empty( $custom ) ) {
			$title_parts['title'] = $custom;
		}
	}
	return $title_parts;
}
add_filter( 'document_title_parts', 'bookboochi_document_title_parts' );

/**
 * Current absolute URL (used as canonical fallback on non-singular views).
 */
function bookboochi_get_current_url() {
	global $wp;
	return home_url( add_query_arg( array(), $wp->request ) );
}

/**
 * Parse the "Q: ... / A: ..." FAQ meta box field into a structured array.
 * Shared by the on-page renderer (template-parts/faq.php) and the
 * FAQPage JSON-LD generator in inc/aeo-geo.php.
 */
function bookboochi_get_faq_pairs( $post_id ) {
	$raw = get_post_meta( $post_id, '_bookboochi_faq', true );
	if ( empty( $raw ) ) {
		return array();
	}

	$lines = preg_split( '/\R/', trim( $raw ) );
	$pairs = array();
	$question = '';

	foreach ( $lines as $line ) {
		$line = trim( $line );
		if ( '' === $line ) {
			continue;
		}
		if ( 0 === stripos( $line, 'Q:' ) ) {
			$question = trim( substr( $line, 2 ) );
		} elseif ( 0 === stripos( $line, 'A:' ) && '' !== $question ) {
			$pairs[] = array(
				'question' => $question,
				'answer'   => trim( substr( $line, 2 ) ),
			);
			$question = '';
		}
	}

	return $pairs;
}
