<?php
/**
 * Book review custom fields.
 *
 * Adds a "Book Review Details" meta box to posts. When the "Book title"
 * field is filled in, the single-post template renders a structured
 * review box (template-parts/content-book-review.php) and the AEO/GEO
 * engine (inc/aeo-geo.php) emits matching Book + Review JSON-LD — the
 * combination Google uses for review-star rich results and that AI
 * answer engines use to quote a verdict + rating accurately.
 *
 * @package Bookboochi
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function bookboochi_book_review_meta_box() {
	add_meta_box(
		'bookboochi_book_review',
		__( 'Book Review Details', 'bookboochi' ),
		'bookboochi_book_review_meta_box_html',
		'post',
		'normal',
		'high'
	);
}
add_action( 'add_meta_boxes', 'bookboochi_book_review_meta_box' );

/**
 * Field definitions: meta key => [label, type, description].
 */
function bookboochi_book_review_fields() {
	return array(
		'_bb_book_title'     => array( __( 'Book title', 'bookboochi' ), 'text', __( 'Required to activate the review box & schema.', 'bookboochi' ) ),
		'_bb_book_author'    => array( __( 'Book author', 'bookboochi' ), 'text', '' ),
		'_bb_book_genre'     => array( __( 'Genre', 'bookboochi' ), 'text', __( 'e.g. Historical Fiction', 'bookboochi' ) ),
		'_bb_book_publisher' => array( __( 'Publisher', 'bookboochi' ), 'text', '' ),
		'_bb_book_isbn'      => array( __( 'ISBN', 'bookboochi' ), 'text', '' ),
		'_bb_book_pages'     => array( __( 'Pages', 'bookboochi' ), 'text', '' ),
		'_bb_book_rating'    => array( __( 'Your rating (0–5)', 'bookboochi' ), 'number', __( 'Supports halves, e.g. 3.5', 'bookboochi' ) ),
		'_bb_verdict'        => array( __( 'One-line verdict', 'bookboochi' ), 'text', __( 'A short, quotable takeaway — this is what answer engines tend to lift.', 'bookboochi' ) ),
		'_bb_buy_link'       => array( __( 'Buy / find link', 'bookboochi' ), 'url', '' ),
	);
}

function bookboochi_book_review_meta_box_html( $post ) {
	wp_nonce_field( 'bookboochi_book_review_save', 'bookboochi_book_review_nonce' );
	$fields = bookboochi_book_review_fields();
	echo '<table class="form-table">';
	foreach ( $fields as $key => $field ) {
		list( $label, $type, $desc ) = $field;
		$value = get_post_meta( $post->ID, $key, true );
		$input_type = 'number' === $type ? 'number' : ( 'url' === $type ? 'url' : 'text' );
		$extra = 'number' === $type ? ' step="0.5" min="0" max="5"' : '';
		printf(
			'<tr><th style="text-align:left;padding:8px 10px 8px 0;"><label for="%1$s">%2$s</label></th><td style="padding:8px 0;"><input type="%3$s" id="%1$s" name="%1$s" value="%4$s" style="width:100%%;max-width:420px;"%5$s />%6$s</td></tr>',
			esc_attr( $key ),
			esc_html( $label ),
			esc_attr( $input_type ),
			esc_attr( $value ),
			$extra, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			$desc ? '<p class="description">' . esc_html( $desc ) . '</p>' : ''
		);
	}
	echo '</table>';
}

function bookboochi_book_review_meta_box_save( $post_id ) {
	if ( ! isset( $_POST['bookboochi_book_review_nonce'] ) || ! wp_verify_nonce( $_POST['bookboochi_book_review_nonce'], 'bookboochi_book_review_save' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	foreach ( array_keys( bookboochi_book_review_fields() ) as $key ) {
		if ( ! isset( $_POST[ $key ] ) ) {
			continue;
		}
		$raw = wp_unslash( $_POST[ $key ] );
		if ( '_bb_buy_link' === $key ) {
			update_post_meta( $post_id, $key, esc_url_raw( $raw ) );
		} elseif ( '_bb_book_rating' === $key ) {
			$rating = is_numeric( $raw ) ? max( 0, min( 5, (float) $raw ) ) : '';
			update_post_meta( $post_id, $key, $rating );
		} else {
			update_post_meta( $post_id, $key, sanitize_text_field( $raw ) );
		}
	}
}
add_action( 'save_post', 'bookboochi_book_review_meta_box_save' );

/**
 * Whether the current/given post has book-review data.
 */
function bookboochi_is_book_review( $post_id = null ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	return (bool) get_post_meta( $post_id, '_bb_book_title', true );
}

/**
 * Render a row of star characters for a 0–5 rating (half-star aware).
 */
function bookboochi_render_stars( $rating ) {
	$rating = max( 0, min( 5, (float) $rating ) );
	$full   = (int) floor( $rating );
	$half   = ( $rating - $full ) >= 0.5;
	$empty  = 5 - $full - ( $half ? 1 : 0 );

	$out  = str_repeat( '★', $full );
	$out .= $half ? '⯪' : '';
	$out .= str_repeat( '☆', $empty );
	return $out;
}
