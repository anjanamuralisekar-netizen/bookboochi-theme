<?php
/**
 * AEO (Answer Engine Optimization) & GEO (Generative Engine Optimization).
 *
 * Traditional SEO gets a page *ranked*. AEO/GEO is about getting a page
 * *quoted* — by voice assistants, Google's AI Overviews, and chat tools
 * like ChatGPT, Perplexity, and Claude. Three things move that needle and
 * this file implements all three:
 *
 *   1. Structured data (JSON-LD) so machines don't have to guess what a
 *      page is — WebSite, Organization, BreadcrumbList, BlogPosting,
 *      Book + Review, and FAQPage.
 *   2. Content shaped for extraction: a TL;DR/answer block near the top,
 *      an auto-generated table of contents, and clean heading hierarchy.
 *   3. A crawlable, plain-text site summary (llms.txt) plus a robots.txt
 *      that doesn't accidentally block reputable AI crawlers.
 *
 * @package Bookboochi
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* -----------------------------------------------------------------------
 * 1. Structured data (JSON-LD)
 * -------------------------------------------------------------------- */

/**
 * Build the @graph of JSON-LD nodes for the current request.
 */
function bookboochi_build_schema_graph() {
	$graph = array();
	$site_url = home_url( '/' );

	// --- WebSite (with SearchAction so Google can offer a sitelinks search box). ---
	$graph[] = array(
		'@type'           => 'WebSite',
		'@id'             => $site_url . '#website',
		'url'             => $site_url,
		'name'            => get_bloginfo( 'name' ),
		'description'     => get_bloginfo( 'description' ),
		'inLanguage'      => get_locale(),
		'publisher'       => array( '@id' => $site_url . '#publisher' ),
		'potentialAction' => array(
			array(
				'@type'       => 'SearchAction',
				'target'      => array(
					'@type'       => 'EntryPoint',
					'urlTemplate' => $site_url . '?s={search_term_string}',
				),
				'query-input' => 'required name=search_term_string',
			),
		),
	);

	// --- Publisher (Organization) — an explicit trust/authority signal. ---
	$graph[] = array(
		'@type' => 'Organization',
		'@id'   => $site_url . '#publisher',
		'name'  => get_bloginfo( 'name' ),
		'url'   => $site_url,
		'logo'  => array(
			'@type' => 'ImageObject',
			'url'   => bookboochi_get_logo_url(),
		),
	);

	// --- Breadcrumbs (mirrors the visible trail in template-tags.php). ---
	$crumbs = bookboochi_get_breadcrumb_trail();
	if ( count( $crumbs ) > 1 ) {
		$items = array();
		foreach ( $crumbs as $i => $crumb ) {
			$item = array(
				'@type'    => 'ListItem',
				'position' => $i + 1,
				'name'     => $crumb['title'],
			);
			if ( ! empty( $crumb['url'] ) ) {
				$item['item'] = $crumb['url'];
			}
			$items[] = $item;
		}
		$graph[] = array(
			'@type'           => 'BreadcrumbList',
			'@id'             => bookboochi_get_current_url() . '#breadcrumb',
			'itemListElement' => $items,
		);
	}

	// --- Singular post: BlogPosting (+ Book/Review if review meta is filled). ---
	if ( is_singular( 'post' ) ) {
		$post_id     = get_the_ID();
		$permalink   = get_permalink();
		$description = bookboochi_get_seo_description();
		$image       = bookboochi_get_seo_image();
		$author_id   = get_the_author_meta( 'ID' );

		$graph[] = array(
			'@type' => 'Person',
			'@id'   => $permalink . '#author',
			'name'  => get_the_author_meta( 'display_name', $author_id ),
			'url'   => get_author_posts_url( $author_id ),
		);

		$article = array(
			'@type'            => 'BlogPosting',
			'@id'              => $permalink . '#article',
			'mainEntityOfPage' => array(
				'@type' => 'WebPage',
				'@id'   => $permalink,
			),
			'headline'         => get_the_title(),
			'description'      => $description,
			'datePublished'    => get_the_date( DATE_W3C ),
			'dateModified'     => get_the_modified_date( DATE_W3C ),
			'author'           => array( '@id' => $permalink . '#author' ),
			'publisher'        => array( '@id' => $site_url . '#publisher' ),
			'inLanguage'       => get_locale(),
			'wordCount'        => str_word_count( wp_strip_all_tags( get_post_field( 'post_content', $post_id ) ) ),
			'articleSection'   => wp_list_pluck( get_the_category(), 'name' ),
			'keywords'         => wp_list_pluck( get_the_tags() ? get_the_tags() : array(), 'name' ),
		);
		if ( $image ) {
			$article['image'] = array(
				'@type'  => 'ImageObject',
				'url'    => $image,
				'width'  => 1200,
				'height' => 630,
			);
		}
		$graph[] = $article;

		// Book review structured data — this is what lets Google (and AI
		// answer engines) surface a star rating + book identity directly.
		$review_node = bookboochi_build_book_review_schema( $post_id, $permalink );
		if ( $review_node ) {
			$graph[] = $review_node;
		}

		// FAQ block, if the editor filled one in via the SEO meta box.
		$faq_pairs = bookboochi_get_faq_pairs( $post_id );
		if ( ! empty( $faq_pairs ) ) {
			$questions = array();
			foreach ( $faq_pairs as $pair ) {
				$questions[] = array(
					'@type'          => 'Question',
					'name'           => $pair['question'],
					'acceptedAnswer' => array(
						'@type' => 'Answer',
						'text'  => $pair['answer'],
					),
				);
			}
			$graph[] = array(
				'@type'      => 'FAQPage',
				'@id'        => $permalink . '#faq',
				'mainEntity' => $questions,
			);
		}
	}

	return $graph;
}

/**
 * Build the Review (+ nested Book) schema node from the book-review meta
 * box fields, if the post has been marked as a book review.
 */
function bookboochi_build_book_review_schema( $post_id, $permalink ) {
	$book_title = get_post_meta( $post_id, '_bb_book_title', true );
	if ( empty( $book_title ) ) {
		return null;
	}

	$book_author = get_post_meta( $post_id, '_bb_book_author', true );
	$isbn        = get_post_meta( $post_id, '_bb_book_isbn', true );
	$genre       = get_post_meta( $post_id, '_bb_book_genre', true );
	$publisher   = get_post_meta( $post_id, '_bb_book_publisher', true );
	$rating      = get_post_meta( $post_id, '_bb_book_rating', true );

	$book = array(
		'@type' => 'Book',
		'name'  => $book_title,
	);
	if ( $book_author ) {
		$book['author'] = array(
			'@type' => 'Person',
			'name'  => $book_author,
		);
	}
	if ( $isbn ) {
		$book['isbn'] = $isbn;
	}
	if ( $genre ) {
		$book['genre'] = $genre;
	}
	if ( $publisher ) {
		$book['publisher'] = array(
			'@type' => 'Organization',
			'name'  => $publisher,
		);
	}

	$review = array(
		'@type'        => 'Review',
		'@id'          => $permalink . '#review',
		'itemReviewed' => $book,
		'author'       => array( '@id' => $permalink . '#author' ),
		'datePublished' => get_the_date( DATE_W3C, $post_id ),
		'reviewBody'   => bookboochi_get_seo_description(),
		'publisher'    => array( '@id' => home_url( '/' ) . '#publisher' ),
	);

	if ( '' !== $rating && is_numeric( $rating ) ) {
		$review['reviewRating'] = array(
			'@type'       => 'Rating',
			'ratingValue' => (float) $rating,
			'bestRating'  => 5,
			'worstRating' => 0, // Matches the 0–5 scale used by the rating field.
		);
	}

	return $review;
}

function bookboochi_get_logo_url() {
	$custom_logo_id = get_theme_mod( 'custom_logo' );
	if ( $custom_logo_id ) {
		$img = wp_get_attachment_image_src( $custom_logo_id, 'full' );
		if ( $img ) {
			return $img[0];
		}
	}
	return '';
}

/**
 * Print the JSON-LD <script> block.
 */
function bookboochi_output_schema() {
	$graph = bookboochi_build_schema_graph();
	if ( empty( $graph ) ) {
		return;
	}
	$data = array(
		'@context' => 'https://schema.org',
		'@graph'   => array_values( array_filter( $graph ) ),
	);
	// Note: JSON_UNESCAPED_SLASHES is deliberately NOT used here — keeping
	// forward-slash escaping ("\/") means a "</script>" inside any editable
	// field (post title, FAQ answer, category name, ...) can't prematurely
	// close this inline <script> block.
	echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
}
add_action( 'wp_footer', 'bookboochi_output_schema' );

/* -----------------------------------------------------------------------
 * 2. Content shaped for extraction: TL;DR block + auto table of contents.
 * -------------------------------------------------------------------- */

/**
 * [bb_tldr] shortcode — a short, quotable answer/summary block placed near
 * the top of a post. This is the single highest-leverage AEO/GEO element:
 * assistants overwhelmingly lift the first clearly-labelled, self-contained
 * answer paragraph they find.
 *
 * Usage: [bb_tldr]Your 2-3 sentence summary here.[/bb_tldr]
 */
function bookboochi_tldr_shortcode( $atts, $content = '' ) {
	if ( empty( $content ) ) {
		return '';
	}
	return sprintf(
		'<div class="bb-tldr"><p class="bb-tldr-label">%s</p>%s</div>',
		esc_html__( 'In short', 'bookboochi' ),
		wpautop( do_shortcode( trim( $content ) ) )
	);
}
add_shortcode( 'bb_tldr', 'bookboochi_tldr_shortcode' );

/**
 * Auto-build a table of contents from H2/H3 headings in post content, and
 * slugify those headings with real ids so the TOC can deep-link to them.
 * A visible, well-linked TOC helps both users and assistants map a long
 * post's structure before deciding what to quote.
 */
function bookboochi_add_toc( $content ) {
	if ( ! is_singular( 'post' ) || ! is_main_query() || ! in_the_loop() ) {
		return $content;
	}
	if ( false !== strpos( $content, 'bb-toc' ) ) {
		return $content; // Avoid double-processing.
	}

	preg_match_all( '/<h([2-3])([^>]*)>(.*?)<\/h\1>/i', $content, $matches, PREG_SET_ORDER );
	if ( count( $matches ) < 3 ) {
		return $content; // Not worth a TOC for a short post.
	}

	$toc_items  = array();
	$used_slugs = array();

	// Single pass over the content so identical/duplicate headings each get
	// their own id instead of a str_replace() clobbering every occurrence.
	$content = preg_replace_callback(
		'/<h([2-3])([^>]*)>(.*?)<\/h\1>/i',
		function ( $match ) use ( &$toc_items, &$used_slugs ) {
			$level      = (int) $match[1];
			$attrs      = $match[2];
			$inner_html = $match[3];
			$text       = wp_strip_all_tags( $inner_html );

			// Respect an id the editor already set (e.g. a Gutenberg "HTML
			// anchor"); only generate one when the heading doesn't have one.
			if ( preg_match( '/\bid=["\']([^"\']+)["\']/i', $attrs, $id_match ) ) {
				$slug = $id_match[1];
			} else {
				$slug = sanitize_title( $text );
				if ( '' === $slug ) {
					$slug = 'section';
				}
				if ( isset( $used_slugs[ $slug ] ) ) {
					$used_slugs[ $slug ]++;
					$slug .= '-' . $used_slugs[ $slug ];
				} else {
					$used_slugs[ $slug ] = 1;
				}
				$attrs .= ' id="' . esc_attr( $slug ) . '"';
			}

			$toc_items[] = array(
				'level' => $level,
				'text'  => $text,
				'slug'  => $slug,
			);

			return '<h' . $level . $attrs . '>' . $inner_html . '</h' . $level . '>';
		},
		$content
	);

	$toc_html  = '<details class="bb-toc" open><summary>' . esc_html__( 'Contents', 'bookboochi' ) . '</summary><ol>';
	foreach ( $toc_items as $item ) {
		$toc_html .= sprintf(
			'<li class="bb-toc-h%1$d"><a href="#%2$s">%3$s</a></li>',
			$item['level'],
			esc_attr( $item['slug'] ),
			esc_html( $item['text'] )
		);
	}
	$toc_html .= '</ol></details>';

	return $toc_html . $content;
}
add_filter( 'the_content', 'bookboochi_add_toc', 9 );

/* -----------------------------------------------------------------------
 * 3. Crawlable summaries: llms.txt + robots.txt hygiene.
 * -------------------------------------------------------------------- */

/**
 * Register /llms.txt — a plain-text, high-signal summary of the site
 * (name, description, and key links) written for large-language-model
 * crawlers, following the emerging llms.txt convention. This gives
 * generative engines a cheap, reliable way to understand the whole site
 * without having to crawl and infer it from HTML.
 */
function bookboochi_llms_txt_rewrite() {
	add_rewrite_rule( '^llms\.txt$', 'index.php?bookboochi_llms_txt=1', 'top' );
}
add_action( 'init', 'bookboochi_llms_txt_rewrite' );

function bookboochi_llms_txt_query_var( $vars ) {
	$vars[] = 'bookboochi_llms_txt';
	return $vars;
}
add_filter( 'query_vars', 'bookboochi_llms_txt_query_var' );

function bookboochi_llms_txt_render() {
	if ( ! get_query_var( 'bookboochi_llms_txt' ) ) {
		return;
	}

	header( 'Content-Type: text/plain; charset=utf-8' );

	$lines   = array();
	$lines[] = '# ' . get_bloginfo( 'name' );
	$lines[] = '> ' . get_bloginfo( 'description' );
	$lines[] = '';
	$lines[] = 'Bookboochi is a book review and reading blog. Posts cover book ' .
		'recommendations, historical fiction, children\'s books, and reader reflections.';
	$lines[] = '';
	$lines[] = '## Site';
	$lines[] = '- Homepage: ' . home_url( '/' );
	$lines[] = '- Sitemap: ' . home_url( '/wp-sitemap.xml' );

	$categories = get_categories( array( 'hide_empty' => true, 'number' => 15 ) );
	if ( $categories ) {
		$lines[] = '';
		$lines[] = '## Categories';
		foreach ( $categories as $cat ) {
			$lines[] = '- [' . $cat->name . '](' . get_category_link( $cat ) . ')';
		}
	}

	$recent = get_posts( array( 'numberposts' => 10, 'post_status' => 'publish' ) );
	if ( $recent ) {
		$lines[] = '';
		$lines[] = '## Recent posts';
		foreach ( $recent as $p ) {
			$excerpt = wp_trim_words( wp_strip_all_tags( $p->post_content ), 20, '…' );
			$lines[] = '- [' . get_the_title( $p ) . '](' . get_permalink( $p ) . '): ' . $excerpt;
		}
	}

	echo implode( "\n", $lines ) . "\n";
	exit;
}
add_action( 'template_redirect', 'bookboochi_llms_txt_render' );

/**
 * Flush rewrite rules once on theme activation so /llms.txt resolves
 * immediately instead of requiring a manual permalinks re-save.
 */
function bookboochi_flush_rewrites_on_switch() {
	bookboochi_llms_txt_rewrite();
	flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'bookboochi_flush_rewrites_on_switch' );

/**
 * Append a Sitemap: line and an explicit allow for well-behaved AI
 * crawlers to the virtual robots.txt (WordPress core generates this
 * dynamically at /robots.txt when no physical robots.txt file exists).
 * Being *allowed* is a prerequisite for GEO — an engine can't cite what
 * it isn't permitted to fetch.
 */
function bookboochi_robots_txt( $output, $public ) {
	if ( '1' !== (string) $public ) {
		return $output; // Site set to discourage indexing — don't override that.
	}

	$output .= "\n# AI answer/generative engines — explicitly allowed to crawl and cite this site.\n";
	foreach ( array( 'GPTBot', 'ChatGPT-User', 'PerplexityBot', 'ClaudeBot', 'Claude-User', 'Google-Extended', 'Applebot-Extended' ) as $bot ) {
		$output .= "User-agent: {$bot}\nAllow: /\n\n";
	}
	$output .= 'Sitemap: ' . home_url( '/wp-sitemap.xml' ) . "\n";
	$output .= 'Sitemap: ' . home_url( '/llms.txt' ) . "\n";

	return $output;
}
add_filter( 'robots_txt', 'bookboochi_robots_txt', 10, 2 );
