<?php
/**
 * Theme Customizer: accent color, social links, footer text.
 *
 * @package Bookboochi
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function bookboochi_customize_register( $wp_customize ) {
	// -- Site identity: description used as tagline for SEO meta too. --
	$wp_customize->get_setting( 'blogdescription' )->transport = 'postMessage';

	// -- Theme colors. --
	$wp_customize->add_section(
		'bookboochi_colors',
		array(
			'title'    => __( 'Bookboochi Colors', 'bookboochi' ),
			'priority' => 30,
		)
	);

	$wp_customize->add_setting(
		'bookboochi_accent_color',
		array(
			'default'           => '#a8461f',
			'sanitize_callback' => 'sanitize_hex_color',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'bookboochi_accent_color',
			array(
				'label'   => __( 'Accent Color', 'bookboochi' ),
				'section' => 'bookboochi_colors',
			)
		)
	);

	$wp_customize->add_setting(
		'bookboochi_gold_color',
		array(
			'default'           => '#b6862c',
			'sanitize_callback' => 'sanitize_hex_color',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'bookboochi_gold_color',
			array(
				'label'   => __( 'Rating / Gold Color', 'bookboochi' ),
				'section' => 'bookboochi_colors',
			)
		)
	);

	// -- Social links. --
	$wp_customize->add_section(
		'bookboochi_social',
		array(
			'title'    => __( 'Social Links', 'bookboochi' ),
			'priority' => 35,
		)
	);

	$socials = array(
		'instagram'  => 'Instagram',
		'goodreads'  => 'Goodreads',
		'twitter'    => 'Twitter / X',
		'pinterest'  => 'Pinterest',
		'youtube'    => 'YouTube',
	);
	foreach ( $socials as $key => $label ) {
		$wp_customize->add_setting(
			"bookboochi_social_{$key}",
			array(
				'default'           => '',
				'sanitize_callback' => 'esc_url_raw',
			)
		);
		$wp_customize->add_control(
			"bookboochi_social_{$key}",
			array(
				'label'   => $label,
				'section' => 'bookboochi_social',
				'type'    => 'url',
			)
		);
	}

	// -- Footer text. --
	$wp_customize->add_section(
		'bookboochi_footer',
		array(
			'title'    => __( 'Footer', 'bookboochi' ),
			'priority' => 120,
		)
	);
	$wp_customize->add_setting(
		'bookboochi_footer_text',
		array(
			'default'           => '',
			'sanitize_callback' => 'wp_kses_post',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'bookboochi_footer_text',
		array(
			'label'       => __( 'Footer credit text', 'bookboochi' ),
			'description' => __( 'Leave blank for the default "© Site Name" line.', 'bookboochi' ),
			'section'     => 'bookboochi_footer',
			'type'        => 'text',
		)
	);
}
add_action( 'customize_register', 'bookboochi_customize_register' );

/**
 * Output the customizer color choices as CSS custom-property overrides.
 */
function bookboochi_customizer_css() {
	$accent = get_theme_mod( 'bookboochi_accent_color', '#a8461f' );
	$gold   = get_theme_mod( 'bookboochi_gold_color', '#b6862c' );
	?>
	<style id="bookboochi-customizer-css">
		:root {
			--bb-accent: <?php echo esc_html( $accent ); ?>;
			--bb-link: <?php echo esc_html( $accent ); ?>;
			--bb-gold: <?php echo esc_html( $gold ); ?>;
		}
	</style>
	<?php
}
add_action( 'wp_head', 'bookboochi_customizer_css', 20 );

/**
 * Social links list used in the footer.
 */
function bookboochi_get_social_links() {
	$socials = array(
		'instagram' => __( 'Instagram', 'bookboochi' ),
		'goodreads' => __( 'Goodreads', 'bookboochi' ),
		'twitter'   => __( 'Twitter / X', 'bookboochi' ),
		'pinterest' => __( 'Pinterest', 'bookboochi' ),
		'youtube'   => __( 'YouTube', 'bookboochi' ),
	);
	$links = array();
	foreach ( $socials as $key => $label ) {
		$url = get_theme_mod( "bookboochi_social_{$key}" );
		if ( $url ) {
			$links[ $key ] = array(
				'label' => $label,
				'url'   => $url,
			);
		}
	}
	return $links;
}
