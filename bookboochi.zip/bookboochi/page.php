<?php
/**
 * Static page template.
 *
 * @package Bookboochi
 */

get_header();
?>

<div class="bb-layout bb-no-sidebar">
	<div class="bb-container-narrow" style="padding:0;">
		<?php
		while ( have_posts() ) :
			the_post();
			?>
			<article id="post-<?php the_ID(); ?>" <?php post_class( 'bb-single' ); ?>>

				<?php bookboochi_breadcrumbs(); ?>

				<header class="bb-post-header">
					<h1 class="bb-post-title"><?php the_title(); ?></h1>
				</header>

				<?php bookboochi_featured_image( 'large' ); ?>

				<div class="bb-entry-content">
					<?php
					the_content();
					wp_link_pages(
						array(
							'before' => '<nav class="bb-pagination page-links" aria-label="' . esc_attr__( 'Page', 'bookboochi' ) . '"><span>' . esc_html__( 'Pages:', 'bookboochi' ) . '</span>',
							'after'  => '</nav>',
						)
					);
					?>
				</div>
			</article>

			<?php
			if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif;
		endwhile;
		?>
	</div>
</div>

<?php
get_footer();
