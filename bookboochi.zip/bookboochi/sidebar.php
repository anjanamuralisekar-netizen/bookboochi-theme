<?php
/**
 * Sidebar template.
 *
 * @package Bookboochi
 */

if ( ! is_active_sidebar( 'sidebar-1' ) ) {
	return;
}
?>
<aside class="bb-sidebar" aria-label="<?php esc_attr_e( 'Sidebar', 'bookboochi' ); ?>">
	<?php dynamic_sidebar( 'sidebar-1' ); ?>
</aside>
