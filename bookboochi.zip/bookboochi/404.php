<?php
/**
 * 404 template.
 *
 * @package Bookboochi
 */

get_header();
?>

<div class="bb-error-404">
	<span class="bb-eyebrow">404</span>
	<h1><?php esc_html_e( 'This page has wandered off', 'bookboochi' ); ?></h1>
	<p><?php esc_html_e( "We couldn't find what you were looking for. Try searching, or head back to the homepage.", 'bookboochi' ); ?></p>
	<?php get_search_form(); ?>
	<p style="margin-top:2rem;">
		<a class="bb-btn" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Back to homepage', 'bookboochi' ); ?></a>
	</p>
</div>

<?php
get_footer();
