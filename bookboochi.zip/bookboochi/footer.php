<?php
/**
 * Footer template.
 *
 * @package Bookboochi
 */
?>
	</div><!-- .bb-container -->
</main><!-- #bb-content -->

<footer class="bb-site-footer">
	<div class="bb-container">
		<?php if ( is_active_sidebar( 'footer-1' ) || is_active_sidebar( 'footer-2' ) || is_active_sidebar( 'footer-3' ) ) : ?>
			<div class="bb-footer-grid">
				<?php foreach ( array( 'footer-1', 'footer-2', 'footer-3' ) as $id ) : ?>
					<?php if ( is_active_sidebar( $id ) ) : ?>
						<div><?php dynamic_sidebar( $id ); ?></div>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>

		<?php
		$social_links = bookboochi_get_social_links();
		if ( ! empty( $social_links ) ) :
			?>
			<div class="bb-footer-social">
				<ul class="bb-author-links" style="list-style:none;padding:0;">
					<?php foreach ( $social_links as $link ) : ?>
						<li style="display:inline;"><a href="<?php echo esc_url( $link['url'] ); ?>" rel="me noopener" target="_blank"><?php echo esc_html( $link['label'] ); ?></a></li>
					<?php endforeach; ?>
				</ul>
			</div>
		<?php endif; ?>

		<div class="bb-footer-bottom">
			<p>
				<?php
				$footer_text = get_theme_mod( 'bookboochi_footer_text' );
				if ( $footer_text ) {
					echo wp_kses_post( $footer_text );
				} else {
					printf(
						/* translators: 1: current year, 2: site name */
						esc_html__( '© %1$s %2$s. All rights reserved.', 'bookboochi' ),
						esc_html( gmdate( 'Y' ) ),
						esc_html( get_bloginfo( 'name' ) )
					);
				}
				?>
			</p>
			<nav aria-label="<?php esc_attr_e( 'Footer', 'bookboochi' ); ?>">
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'footer',
						'container'      => false,
						'fallback_cb'    => false,
						'depth'          => 1,
					)
				);
				?>
			</nav>
		</div>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
