<?php
/**
 * Plugin Name: Bookboochi Library
 * Plugin URI: https://bookboochi.site
 * Description: Adds a "Book Details" entry form (title, series, author, genre, publisher, ISBN, format, pages, rating, cover) to your posts, displays it in a structured box on the front end, and lets readers browse your reviews by author and genre.
 * Version: 1.0.0
 * Requires at least: 6.4
 * Requires PHP: 7.4
 * Author: Anjana
 * Author URI: https://bookboochi.site
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: bookboochi-library
 *
 * @package Bookboochi_Library
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'BBL_VERSION', '1.0.0' );
define( 'BBL_FILE', __FILE__ );
define( 'BBL_DIR', plugin_dir_path( __FILE__ ) );
define( 'BBL_URL', plugin_dir_url( __FILE__ ) );

/**
 * Load plugin pieces. Order matters: taxonomies must be registered before
 * anything that references them (meta box term-select UI, schema output).
 */
function bbl_load() {
	require_once BBL_DIR . 'includes/class-bbl-taxonomies.php';
	require_once BBL_DIR . 'includes/class-bbl-meta-box.php';
	require_once BBL_DIR . 'includes/class-bbl-display.php';
	require_once BBL_DIR . 'includes/class-bbl-shortcode.php';
	require_once BBL_DIR . 'includes/class-bbl-admin-columns.php';
	require_once BBL_DIR . 'includes/class-bbl-schema.php';

	BBL_Taxonomies::init();
	BBL_Meta_Box::init();
	BBL_Display::init();
	BBL_Shortcode::init();
	BBL_Admin_Columns::init();
	BBL_Schema::init();
}
add_action( 'plugins_loaded', 'bbl_load' );

/**
 * Flush rewrite rules on activation/deactivation so the new author/genre
 * archive URLs (e.g. /book-genre/historical-fiction/) work immediately
 * without a manual visit to Settings → Permalinks.
 */
function bbl_activate() {
	require_once BBL_DIR . 'includes/class-bbl-taxonomies.php';
	BBL_Taxonomies::register();
	flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'bbl_activate' );

function bbl_deactivate() {
	flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'bbl_deactivate' );
