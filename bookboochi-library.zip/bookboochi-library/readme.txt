=== Bookboochi Library ===
Contributors: anjanadevi
Requires at least: 6.4
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Tags: books, book review, library, catalog, taxonomy

Adds a "Book Details" entry form to your posts (title, series, author,
genre, publisher, ISBN, format, pages, source, your rating), displays it
as a structured box on the front end, and lets readers browse your
reviews by author and genre. Works with any theme.

== Description ==

This plugin does three things:

1. **Data entry.** Every post gets a "Book Details" meta box below the
   editor. Fill in what applies — only the Book Title field is required
   to activate the box on the front end. The book cover is your post's
   normal Featured Image (no separate upload field needed).
2. **Display.** A structured box is automatically shown above the post
   content on any post with book details filled in — cover, title,
   series, author, genre, publisher, ISBN, release date, format, pages,
   source, and your star rating.
3. **Organizing.** Author and Genre are real WordPress taxonomies, so
   every author and genre automatically gets its own browsable page
   (e.g. `/book-author/jhumpa-lahiri/`, `/book-genre/historical-fiction/`).
   Use the `[bb_library]` shortcode on any page to show a filterable grid
   of every book you've reviewed.

Also included: Book + Review structured data (JSON-LD) on every book
post, for search engines and AI answer/generative tools; sortable
Author/Genre/Rating columns on the Posts screen.

== Installation ==

1. Plugins → Add New → Upload Plugin, choose `bookboochi-library.zip`,
   Install Now, then Activate.
2. Settings → Permalinks → click Save once (activates the new
   `/book-author/` and `/book-genre/` archive URLs cleanly).
3. Open any post, scroll to "Book Details," and fill it in.
4. Optional: create a page called "Bookshelf" and add the shortcode
   `[bb_library]` to it for a full browsable grid.

== A note if you're using the Bookboochi theme's own book-review box ==

The Bookboochi theme (if installed) has its own similar-looking "Book
Review Details" box built in. This plugin uses different field names
behind the scenes, so the two won't conflict or double up — but to avoid
confusion, use this plugin's box going forward and simply leave the
theme's box empty on new posts. Posts you already filled in using the
theme's box will keep displaying via the theme as before; this plugin's
box (and the taxonomy browsing) is additive.

== Shortcode reference ==

`[bb_library]` — grid of every book, 12 per page, with Genre/Author filter
dropdowns.

`[bb_library genre="historical-fiction"]` — pre-filtered to one genre.

`[bb_library author="jhumpa-lahiri" per_page="6"]` — pre-filtered to one
author, 6 per page.

== Changelog ==

= 1.0.0 =
* Initial release.
