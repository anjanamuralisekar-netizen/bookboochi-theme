<?php
/**
 * Registers the Author and Genre taxonomies on the standard "post" type,
 * so reviews can be organized/browsed by either one — automatically, via
 * WordPress's normal taxonomy archive pages.
 *
 * @package Bookboochi_Library
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BBL_Taxonomies {

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
	}

	public static function register() {
		register_taxonomy(
			'bbl_author',
			'post',
			array(
				'labels'            => array(
					'name'          => __( 'Book Authors', 'bookboochi-library' ),
					'singular_name' => __( 'Book Author', 'bookboochi-library' ),
					'search_items'  => __( 'Search Authors', 'bookboochi-library' ),
					'all_items'     => __( 'All Authors', 'bookboochi-library' ),
					'edit_item'     => __( 'Edit Author', 'bookboochi-library' ),
					'update_item'   => __( 'Update Author', 'bookboochi-library' ),
					'add_new_item'  => __( 'Add New Author', 'bookboochi-library' ),
					'new_item_name' => __( 'New Author Name', 'bookboochi-library' ),
					'menu_name'     => __( 'Authors', 'bookboochi-library' ),
					'not_found'     => __( 'No authors found.', 'bookboochi-library' ),
				),
				'hierarchical'      => false, // Tag-style: type a name, comma-add more than one.
				'public'            => true,
				'show_ui'           => true,
				'show_admin_column' => false, // We add our own richer column — see class-bbl-admin-columns.php.
				'show_in_rest'      => true,
				'show_in_menu'      => true,
				'show_in_nav_menus' => true,
				'query_var'         => true,
				'rewrite'           => array(
					'slug'         => 'book-author',
					'with_front'   => false,
					'hierarchical' => false,
				),
			)
		);

		register_taxonomy(
			'bbl_genre',
			'post',
			array(
				'labels'            => array(
					'name'          => __( 'Book Genres', 'bookboochi-library' ),
					'singular_name' => __( 'Book Genre', 'bookboochi-library' ),
					'search_items'  => __( 'Search Genres', 'bookboochi-library' ),
					'all_items'     => __( 'All Genres', 'bookboochi-library' ),
					'edit_item'     => __( 'Edit Genre', 'bookboochi-library' ),
					'update_item'   => __( 'Update Genre', 'bookboochi-library' ),
					'add_new_item'  => __( 'Add New Genre', 'bookboochi-library' ),
					'new_item_name' => __( 'New Genre Name', 'bookboochi-library' ),
					'menu_name'     => __( 'Genres', 'bookboochi-library' ),
					'not_found'     => __( 'No genres found.', 'bookboochi-library' ),
				),
				'hierarchical'      => false, // Tag-style, so a book can carry more than one genre.
				'public'            => true,
				'show_ui'           => true,
				'show_admin_column' => false,
				'show_in_rest'      => true,
				'show_in_menu'      => true,
				'show_in_nav_menus' => true,
				'query_var'         => true,
				'rewrite'           => array(
					'slug'         => 'book-genre',
					'with_front'   => false,
					'hierarchical' => false,
				),
			)
		);
	}
}
