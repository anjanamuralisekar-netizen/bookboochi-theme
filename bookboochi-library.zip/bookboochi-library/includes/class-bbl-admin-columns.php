<?php
/**
 * Custom columns on the Posts admin list table, so reviews with book
 * data are easy to scan and sort without opening each one.
 *
 * @package Bookboochi_Library
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BBL_Admin_Columns {

	public static function init() {
		add_filter( 'manage_post_posts_columns', array( __CLASS__, 'add_columns' ) );
		add_action( 'manage_post_posts_custom_column', array( __CLASS__, 'render_column' ), 10, 2 );
		add_filter( 'manage_edit-post_sortable_columns', array( __CLASS__, 'sortable_columns' ) );
		add_action( 'pre_get_posts', array( __CLASS__, 'sort_by_meta' ) );
	}

	public static function add_columns( $columns ) {
		$new = array();
		foreach ( $columns as $key => $label ) {
			$new[ $key ] = $label;
			if ( 'title' === $key ) {
				$new['bbl_book_title'] = __( 'Book', 'bookboochi-library' );
				$new['bbl_author']     = __( 'Author', 'bookboochi-library' );
				$new['bbl_genre']      = __( 'Genre', 'bookboochi-library' );
				$new['bbl_rating']     = __( 'Rating', 'bookboochi-library' );
			}
		}
		return $new;
	}

	public static function render_column( $column, $post_id ) {
		switch ( $column ) {
			case 'bbl_book_title':
				echo esc_html( get_post_meta( $post_id, '_bbl_book_title', true ) ?: '—' );
				break;

			case 'bbl_author':
				$terms = get_the_terms( $post_id, 'bbl_author' );
				echo ( $terms && ! is_wp_error( $terms ) ) ? esc_html( implode( ', ', wp_list_pluck( $terms, 'name' ) ) ) : '—';
				break;

			case 'bbl_genre':
				$terms = get_the_terms( $post_id, 'bbl_genre' );
				echo ( $terms && ! is_wp_error( $terms ) ) ? esc_html( implode( ', ', wp_list_pluck( $terms, 'name' ) ) ) : '—';
				break;

			case 'bbl_rating':
				$rating = get_post_meta( $post_id, '_bbl_rating', true );
				echo '' !== $rating ? esc_html( $rating . '/5' ) : '—';
				break;
		}
	}

	public static function sortable_columns( $columns ) {
		$columns['bbl_book_title'] = 'bbl_book_title';
		$columns['bbl_rating']     = 'bbl_rating';
		return $columns;
	}

	public static function sort_by_meta( $query ) {
		if ( ! is_admin() || ! $query->is_main_query() ) {
			return;
		}
		$orderby = $query->get( 'orderby' );
		if ( 'bbl_book_title' === $orderby ) {
			$query->set( 'meta_key', '_bbl_book_title' );
			$query->set( 'orderby', 'meta_value' );
		} elseif ( 'bbl_rating' === $orderby ) {
			$query->set( 'meta_key', '_bbl_rating' );
			$query->set( 'orderby', 'meta_value_num' );
		}
	}
}
