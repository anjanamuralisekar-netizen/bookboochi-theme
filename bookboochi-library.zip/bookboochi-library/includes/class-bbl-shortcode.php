<?php
/**
 * [bb_library] shortcode — a browsable, filterable grid of every review
 * that has book details filled in. Drop it on any page (e.g. a
 * "Bookshelf" page) to get a library view organized by author and genre,
 * on top of the automatic per-term archive pages WordPress already
 * provides at /book-author/{slug}/ and /book-genre/{slug}/.
 *
 * Usage: [bb_library]
 *        [bb_library genre="historical-fiction" per_page="9"]
 *        [bb_library author="jhumpa-lahiri"]
 *
 * @package Bookboochi_Library
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BBL_Shortcode {

	public static function init() {
		add_shortcode( 'bb_library', array( __CLASS__, 'render' ) );
	}

	public static function render( $atts ) {
		$atts = shortcode_atts(
			array(
				'genre'    => '',
				'author'   => '',
				'per_page' => 12,
				'orderby'  => 'title',
				'order'    => 'ASC',
			),
			$atts,
			'bb_library'
		);

		wp_enqueue_style( 'bookboochi-library' );

		// GET params on the page this shortcode lives on let a reader
		// switch filters without needing a separate archive template.
		// Deliberately named "bbl_f_*" (not "bbl_genre"/"bbl_author") —
		// those are the taxonomies' own public query vars, and reusing
		// them here would make WordPress's main-query URL parsing treat
		// this shortcode's filter links as taxonomy-archive requests for
		// whatever ordinary page the shortcode is placed on, 404-ing it.
		$selected_genre  = ( isset( $_GET['bbl_f_genre'] ) && ! is_array( $_GET['bbl_f_genre'] ) ) ? sanitize_title( wp_unslash( $_GET['bbl_f_genre'] ) ) : $atts['genre'];
		$selected_author = ( isset( $_GET['bbl_f_author'] ) && ! is_array( $_GET['bbl_f_author'] ) ) ? sanitize_title( wp_unslash( $_GET['bbl_f_author'] ) ) : $atts['author'];
		$paged           = isset( $_GET['bbl_paged'] ) && ! is_array( $_GET['bbl_paged'] ) ? max( 1, (int) $_GET['bbl_paged'] ) : 1;

		$tax_query = array();
		if ( $selected_genre ) {
			$tax_query[] = array(
				'taxonomy' => 'bbl_genre',
				'field'    => 'slug',
				'terms'    => $selected_genre,
			);
		}
		if ( $selected_author ) {
			$tax_query[] = array(
				'taxonomy' => 'bbl_author',
				'field'    => 'slug',
				'terms'    => $selected_author,
			);
		}

		$query = new WP_Query(
			array(
				'post_type'      => 'post',
				'post_status'    => 'publish',
				'posts_per_page' => (int) $atts['per_page'],
				'paged'          => $paged,
				'orderby'        => sanitize_key( $atts['orderby'] ),
				'order'          => 'DESC' === strtoupper( $atts['order'] ) ? 'DESC' : 'ASC',
				'meta_key'       => '_bbl_book_title',
				'meta_compare'   => 'EXISTS',
				'tax_query'      => $tax_query, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- small, deliberate library-page query, not run on every page load.
			)
		);

		ob_start();
		?>
		<div class="bbl-library">
			<form class="bbl-library-filters" method="get">
				<?php self::preserve_other_query_args(); ?>
				<label class="screen-reader-text" for="bbl-filter-genre"><?php esc_html_e( 'Filter by genre', 'bookboochi-library' ); ?></label>
				<select id="bbl-filter-genre" name="bbl_f_genre" onchange="this.form.submit()">
					<option value=""><?php esc_html_e( 'All genres', 'bookboochi-library' ); ?></option>
					<?php $genre_terms = get_terms( array( 'taxonomy' => 'bbl_genre', 'hide_empty' => true ) ); ?>
					<?php foreach ( ( is_wp_error( $genre_terms ) ? array() : $genre_terms ) as $term ) : ?>
						<option value="<?php echo esc_attr( $term->slug ); ?>" <?php selected( $selected_genre, $term->slug ); ?>><?php echo esc_html( $term->name ); ?></option>
					<?php endforeach; ?>
				</select>

				<label class="screen-reader-text" for="bbl-filter-author"><?php esc_html_e( 'Filter by author', 'bookboochi-library' ); ?></label>
				<select id="bbl-filter-author" name="bbl_f_author" onchange="this.form.submit()">
					<option value=""><?php esc_html_e( 'All authors', 'bookboochi-library' ); ?></option>
					<?php $author_terms = get_terms( array( 'taxonomy' => 'bbl_author', 'hide_empty' => true ) ); ?>
					<?php foreach ( ( is_wp_error( $author_terms ) ? array() : $author_terms ) as $term ) : ?>
						<option value="<?php echo esc_attr( $term->slug ); ?>" <?php selected( $selected_author, $term->slug ); ?>><?php echo esc_html( $term->name ); ?></option>
					<?php endforeach; ?>
				</select>

				<noscript><button type="submit" class="button"><?php esc_html_e( 'Filter', 'bookboochi-library' ); ?></button></noscript>

				<?php if ( $selected_genre || $selected_author ) : ?>
					<a class="bbl-reset" href="<?php echo esc_url( remove_query_arg( array( 'bbl_f_genre', 'bbl_f_author', 'bbl_paged' ) ) ); ?>"><?php esc_html_e( 'Reset filters', 'bookboochi-library' ); ?></a>
				<?php endif; ?>
			</form>

			<?php if ( $query->have_posts() ) : ?>
				<div class="bbl-library-grid">
					<?php while ( $query->have_posts() ) : $query->the_post(); ?>
						<?php self::render_card( get_the_ID() ); ?>
					<?php endwhile; ?>
				</div>
				<?php self::render_pagination( $query, $paged ); ?>
			<?php else : ?>
				<p class="bbl-library-empty"><?php esc_html_e( 'No books match this filter yet.', 'bookboochi-library' ); ?></p>
			<?php endif; ?>
		</div>
		<?php
		wp_reset_postdata();
		return ob_get_clean();
	}

	/**
	 * Re-emit any other GET params already on the page (so this shortcode
	 * plays nicely if it shares a page with other query-string-driven
	 * widgets) as hidden fields, since a plain <form method="get"> would
	 * otherwise drop them on submit.
	 */
	private static function preserve_other_query_args() {
		$skip = array( 'bbl_f_genre', 'bbl_f_author', 'bbl_paged' );
		foreach ( $_GET as $key => $value ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only filter state, not a state-changing action.
			$key = sanitize_key( $key );
			if ( in_array( $key, $skip, true ) || is_array( $value ) ) {
				continue;
			}
			printf( '<input type="hidden" name="%1$s" value="%2$s" />', esc_attr( $key ), esc_attr( sanitize_text_field( wp_unslash( $value ) ) ) );
		}
	}

	private static function render_card( $post_id ) {
		$rating = get_post_meta( $post_id, '_bbl_rating', true );
		$authors = get_the_terms( $post_id, 'bbl_author' );
		?>
		<article class="bbl-library-card">
			<a class="bbl-library-cover" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
				<?php if ( has_post_thumbnail() ) : ?>
					<?php the_post_thumbnail( 'medium' ); ?>
				<?php endif; ?>
			</a>
			<h3><a href="<?php the_permalink(); ?>"><?php echo esc_html( get_post_meta( $post_id, '_bbl_book_title', true ) ); ?></a></h3>
			<?php if ( ! empty( $authors ) && ! is_wp_error( $authors ) ) : ?>
				<p class="bbl-library-author"><?php echo esc_html( implode( ', ', wp_list_pluck( $authors, 'name' ) ) ); ?></p>
			<?php endif; ?>
			<?php if ( '' !== $rating ) : ?>
				<span class="bbl-stars" aria-label="<?php echo esc_attr( sprintf( __( 'Rated %s out of 5', 'bookboochi-library' ), $rating ) ); ?>"><?php echo esc_html( BBL_Display::stars_html( $rating ) ); ?></span>
			<?php endif; ?>
		</article>
		<?php
	}

	private static function render_pagination( $query, $current_page ) {
		if ( $query->max_num_pages < 2 ) {
			return;
		}
		echo '<nav class="bbl-library-pagination" aria-label="' . esc_attr__( 'Library pagination', 'bookboochi-library' ) . '">';
		for ( $i = 1; $i <= $query->max_num_pages; $i++ ) {
			if ( $i === $current_page ) {
				printf( '<span class="bbl-current">%d</span>', (int) $i );
			} else {
				printf( '<a href="%1$s">%2$d</a>', esc_url( add_query_arg( 'bbl_paged', $i ) ), (int) $i );
			}
		}
		echo '</nav>';
	}
}
