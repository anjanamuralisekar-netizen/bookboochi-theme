<?php
/**
 * "Book Details" meta box — the data-entry form shown below the post
 * editor. Author and Genre are handled by WordPress's own taxonomy boxes
 * in the sidebar (added automatically because they're registered on
 * "post"); everything else lives here.
 *
 * @package Bookboochi_Library
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BBL_Meta_Box {

	/**
	 * Meta key => [ label, input type, extra HTML attrs, description ].
	 */
	public static function fields() {
		return array(
			'_bbl_book_title'   => array( __( 'Book title', 'bookboochi-library' ), 'text', '', __( 'Required — this is what activates the book box on the post. Can differ from your post title (e.g. post title "The Lowland Review", book title "The Lowland").', 'bookboochi-library' ) ),
			'_bbl_series'       => array( __( 'Series', 'bookboochi-library' ), 'text', '', __( 'Leave blank if this isn\'t part of a series.', 'bookboochi-library' ) ),
			'_bbl_publisher'    => array( __( 'Publisher', 'bookboochi-library' ), 'text', '', '' ),
			'_bbl_isbn'         => array( __( 'ISBN', 'bookboochi-library' ), 'text', '', __( 'ISBN-10 or ISBN-13.', 'bookboochi-library' ) ),
			'_bbl_release_date' => array( __( 'Release date', 'bookboochi-library' ), 'date', '', '' ),
			'_bbl_format'       => array( __( 'Format', 'bookboochi-library' ), 'select', '', '' ),
			'_bbl_pages'        => array( __( 'Pages', 'bookboochi-library' ), 'number', ' min="1" step="1"', '' ),
			'_bbl_source'       => array( __( 'Source', 'bookboochi-library' ), 'text', '', __( 'How you got the book — e.g. Purchased, Library, Gifted, NetGalley, ARC.', 'bookboochi-library' ) ),
			'_bbl_rating'       => array( __( 'Your rating (0–5)', 'bookboochi-library' ), 'number', ' min="0" max="5" step="0.5"', __( 'Supports halves, e.g. 3.5.', 'bookboochi-library' ) ),
		);
	}

	public static function format_options() {
		return array(
			''            => __( '— Select —', 'bookboochi-library' ),
			'Paperback'   => __( 'Paperback', 'bookboochi-library' ),
			'Hardcover'   => __( 'Hardcover', 'bookboochi-library' ),
			'Ebook'       => __( 'Ebook', 'bookboochi-library' ),
			'Audiobook'   => __( 'Audiobook', 'bookboochi-library' ),
			'Other'       => __( 'Other', 'bookboochi-library' ),
		);
	}

	public static function init() {
		add_action( 'add_meta_boxes', array( __CLASS__, 'register' ) );
		add_action( 'save_post', array( __CLASS__, 'save' ) );
	}

	public static function register() {
		add_meta_box(
			'bbl_book_details',
			__( 'Book Details (Bookboochi Library)', 'bookboochi-library' ),
			array( __CLASS__, 'render' ),
			'post',
			'normal',
			'high'
		);
	}

	public static function render( $post ) {
		wp_nonce_field( 'bbl_save_book_details', 'bbl_book_details_nonce' );
		?>
		<p style="background:#f0f6fc;border-left:4px solid #72aee6;padding:8px 12px;">
			<?php esc_html_e( 'Book cover: use the "Featured Image" panel in the sidebar to upload the book cover — it doubles as the cover shown here and the image used when this post is shared on social media.', 'bookboochi-library' ); ?>
		</p>
		<table class="form-table" role="presentation">
			<?php foreach ( self::fields() as $key => $field ) : ?>
				<?php list( $label, $type, $attrs, $desc ) = $field; ?>
				<tr>
					<th style="text-align:left;width:180px;padding:10px 10px 10px 0;">
						<label for="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label>
					</th>
					<td style="padding:10px 0;">
						<?php self::render_field( $post->ID, $key, $type, $attrs ); ?>
						<?php if ( $desc ) : ?>
							<p class="description"><?php echo esc_html( $desc ); ?></p>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
		</table>
		<?php
	}

	private static function render_field( $post_id, $key, $type, $attrs ) {
		$value = get_post_meta( $post_id, $key, true );

		if ( 'select' === $type && '_bbl_format' === $key ) {
			echo '<select id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '">';
			foreach ( self::format_options() as $option_value => $option_label ) {
				printf(
					'<option value="%1$s"%2$s>%3$s</option>',
					esc_attr( $option_value ),
					selected( $value, $option_value, false ),
					esc_html( $option_label )
				);
			}
			echo '</select>';
			return;
		}

		printf(
			'<input type="%1$s" id="%2$s" name="%2$s" value="%3$s" style="width:100%%;max-width:420px;"%4$s />',
			esc_attr( $type ),
			esc_attr( $key ),
			esc_attr( $value ),
			$attrs // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- fixed, hard-coded attribute strings from fields() above, not user input.
		);
	}

	public static function save( $post_id ) {
		if ( ! isset( $_POST['bbl_book_details_nonce'] ) || ! wp_verify_nonce( $_POST['bbl_book_details_nonce'], 'bbl_save_book_details' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( 'post' !== get_post_type( $post_id ) ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		foreach ( array_keys( self::fields() ) as $key ) {
			if ( ! isset( $_POST[ $key ] ) ) {
				continue;
			}
			$raw = wp_unslash( $_POST[ $key ] );

			if ( '_bbl_rating' === $key ) {
				$value = is_numeric( $raw ) ? max( 0, min( 5, (float) $raw ) ) : '';
			} elseif ( '_bbl_pages' === $key ) {
				$value = is_numeric( $raw ) ? max( 0, (int) $raw ) : '';
			} elseif ( '_bbl_release_date' === $key ) {
				// Expecting YYYY-MM-DD from the date input; store only if valid.
				$value = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $raw ) ? $raw : '';
			} elseif ( '_bbl_format' === $key ) {
				$value = array_key_exists( $raw, self::format_options() ) ? $raw : '';
			} else {
				$value = sanitize_text_field( $raw );
			}

			update_post_meta( $post_id, $key, $value );
		}
	}
}
