<?php
/**
 * Book + Review JSON-LD structured data for posts that have book details
 * filled in. This is what lets Google show a star rating in search
 * results and lets AI answer/generative engines quote the book's
 * identity and your verdict accurately.
 *
 * Namespaced to this plugin's own `_bbl_*` meta keys, so it only ever
 * fires for posts filled in through this plugin's meta box — it will
 * never duplicate or conflict with a theme's own review schema, which
 * (if present) reads its own separate meta keys.
 *
 * @package Bookboochi_Library
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BBL_Schema {

	public static function init() {
		add_action( 'wp_footer', array( __CLASS__, 'output' ) );
	}

	public static function output() {
		if ( ! is_singular( 'post' ) ) {
			return;
		}

		$post_id = get_the_ID();
		if ( ! BBL_Display::is_book_post( $post_id ) ) {
			return;
		}

		$graph = self::build( $post_id );
		if ( empty( $graph ) ) {
			return;
		}

		$data = array(
			'@context' => 'https://schema.org',
			'@graph'   => $graph,
		);

		// JSON_UNESCAPED_SLASHES is intentionally omitted: keeping "/"
		// escaped as "\/" stops a "</script>" inside any editable field
		// from prematurely closing this inline <script> block.
		echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
	}

	private static function build( $post_id ) {
		$book_title = get_post_meta( $post_id, '_bbl_book_title', true );
		if ( empty( $book_title ) ) {
			return array();
		}

		$permalink = get_permalink( $post_id );
		$authors   = get_the_terms( $post_id, 'bbl_author' );
		$genres    = get_the_terms( $post_id, 'bbl_genre' );
		$publisher = get_post_meta( $post_id, '_bbl_publisher', true );
		$isbn      = get_post_meta( $post_id, '_bbl_isbn', true );
		$pages     = get_post_meta( $post_id, '_bbl_pages', true );
		$rating    = get_post_meta( $post_id, '_bbl_rating', true );
		$format    = get_post_meta( $post_id, '_bbl_format', true );

		$book = array(
			'@type' => 'Book',
			'name'  => $book_title,
		);
		if ( $authors && ! is_wp_error( $authors ) ) {
			$book['author'] = array_map(
				function ( $term ) {
					return array( '@type' => 'Person', 'name' => $term->name );
				},
				$authors
			);
		}
		if ( $genres && ! is_wp_error( $genres ) ) {
			$book['genre'] = wp_list_pluck( $genres, 'name' );
		}
		if ( $publisher ) {
			$book['publisher'] = array( '@type' => 'Organization', 'name' => $publisher );
		}
		if ( $isbn ) {
			$book['isbn'] = $isbn;
		}
		if ( $pages ) {
			$book['numberOfPages'] = (int) $pages;
		}
		$schema_format = self::map_book_format( $format );
		if ( $schema_format ) {
			$book['bookFormat'] = $schema_format;
		}

		$review = array(
			'@type'         => 'Review',
			'@id'           => $permalink . '#book-review',
			'itemReviewed'  => $book,
			'author'        => array(
				'@type' => 'Person',
				'name'  => get_the_author_meta( 'display_name', (int) get_post_field( 'post_author', $post_id ) ),
			),
			'datePublished' => get_the_date( DATE_W3C, $post_id ),
			'reviewBody'    => wp_trim_words( wp_strip_all_tags( get_post_field( 'post_content', $post_id ) ), 60, '…' ),
			'url'           => $permalink,
		);

		if ( '' !== $rating && is_numeric( $rating ) ) {
			$review['reviewRating'] = array(
				'@type'       => 'Rating',
				'ratingValue' => (float) $rating,
				'bestRating'  => 5,
				'worstRating' => 0,
			);
		}

		return array( $review );
	}

	/**
	 * Map this plugin's Format option to a schema.org BookFormatType URL.
	 */
	private static function map_book_format( $format ) {
		$map = array(
			'Paperback' => 'https://schema.org/Paperback',
			'Hardcover' => 'https://schema.org/Hardcover',
			'Ebook'     => 'https://schema.org/EBook',
			'Audiobook' => 'https://schema.org/AudiobookFormat',
		);
		return isset( $map[ $format ] ) ? $map[ $format ] : '';
	}
}
