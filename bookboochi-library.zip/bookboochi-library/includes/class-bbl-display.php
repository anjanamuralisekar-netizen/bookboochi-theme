<?php
/**
 * Front-end rendering: the "book details" box injected above a review's
 * content, plus shared helpers (star rendering, cover URL, taxonomy
 * term lists) reused by the shortcode and schema classes.
 *
 * Rendering through the `the_content` filter — rather than a theme
 * template file — is what makes this a genuine plugin: it works no
 * matter which theme is active, including if Bookboochi's theme is
 * ever replaced.
 *
 * @package Bookboochi_Library
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BBL_Display {

	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_filter( 'the_content', array( __CLASS__, 'inject_book_box' ), 8 );
	}

	public static function assets() {
		wp_register_style( 'bookboochi-library', BBL_URL . 'assets/css/bookboochi-library.css', array(), BBL_VERSION );
		// Only actually printed on pages that need it — see maybe_enqueue().
	}

	private static function maybe_enqueue() {
		if ( ! wp_style_is( 'bookboochi-library', 'enqueued' ) ) {
			wp_enqueue_style( 'bookboochi-library' );
		}
	}

	/**
	 * Whether a post has book data entered (the book title field is the
	 * on/off switch — same convention used throughout this plugin).
	 */
	public static function is_book_post( $post_id ) {
		return (bool) get_post_meta( $post_id, '_bbl_book_title', true );
	}

	/**
	 * Render 0–5 stars (half-star aware) as safe, already-escaped HTML.
	 */
	public static function stars_html( $rating ) {
		$rating = max( 0, min( 5, (float) $rating ) );
		$full   = (int) floor( $rating );
		$half   = ( $rating - $full ) >= 0.5;
		$empty  = 5 - $full - ( $half ? 1 : 0 );

		return str_repeat( '★', $full ) . ( $half ? '⯪' : '' ) . str_repeat( '☆', $empty );
	}

	/**
	 * Collect a post's book fields into one associative array.
	 */
	public static function get_book_data( $post_id ) {
		$data = array( 'id' => $post_id );
		foreach ( array_keys( BBL_Meta_Box::fields() ) as $key ) {
			$data[ $key ] = get_post_meta( $post_id, $key, true );
		}
		$data['authors'] = get_the_terms( $post_id, 'bbl_author' );
		$data['genres']  = get_the_terms( $post_id, 'bbl_genre' );
		if ( ! is_array( $data['authors'] ) ) {
			$data['authors'] = array();
		}
		if ( ! is_array( $data['genres'] ) ) {
			$data['genres'] = array();
		}
		return $data;
	}

	/**
	 * Prepend the structured book box to a review's content.
	 */
	public static function inject_book_box( $content ) {
		if ( is_admin() || ! is_singular( 'post' ) || ! in_the_loop() || ! is_main_query() ) {
			return $content;
		}

		$post_id = get_the_ID();
		if ( ! self::is_book_post( $post_id ) ) {
			return $content;
		}

		self::maybe_enqueue();

		return self::render_box( self::get_book_data( $post_id ) ) . $content;
	}

	/**
	 * Build the box markup. Cover image = post's Featured Image.
	 */
	public static function render_box( $book ) {
		$rows = array(
			'Series'    => $book['_bbl_series'],
			'Author'    => self::term_names( $book['authors'] ),
			'Genre'     => self::term_names( $book['genres'] ),
			'Publisher' => $book['_bbl_publisher'],
			'ISBN'      => $book['_bbl_isbn'],
			'Release date' => $book['_bbl_release_date'] ? mysql2date( get_option( 'date_format' ), $book['_bbl_release_date'] ) : '',
			'Format'    => $book['_bbl_format'],
			'Pages'     => $book['_bbl_pages'],
			'Source'    => $book['_bbl_source'],
		);

		// Only Author/Genre carry pre-built <a> markup (from term_names());
		// everything else is a plain sanitized string and must be
		// esc_html()'d, not passed through wp_kses_post(), so a future
		// change to how those fields are saved can't turn into an
		// HTML-injection path.
		$html_rows = array( 'Author', 'Genre' );

		ob_start();
		?>
		<aside class="bbl-book-box" aria-label="<?php esc_attr_e( 'Book details', 'bookboochi-library' ); ?>">
			<?php if ( has_post_thumbnail( $book['id'] ) ) : ?>
				<div class="bbl-cover">
					<?php echo get_the_post_thumbnail( $book['id'], 'medium', array( 'alt' => $book['_bbl_book_title'] ) ); ?>
				</div>
			<?php endif; ?>
			<div class="bbl-details">
				<p class="bbl-row bbl-row-title"><strong><?php esc_html_e( 'Title', 'bookboochi-library' ); ?> :</strong> <?php echo esc_html( $book['_bbl_book_title'] ); ?></p>
				<?php foreach ( $rows as $label => $value ) : ?>
					<?php if ( '' === $value || array() === $value ) : continue; endif; ?>
					<p class="bbl-row">
						<strong><?php echo esc_html( $label ); ?> :</strong>
						<?php echo in_array( $label, $html_rows, true ) ? wp_kses_post( $value ) : esc_html( $value ); ?>
					</p>
				<?php endforeach; ?>

				<?php if ( '' !== $book['_bbl_rating'] ) : ?>
					<p class="bbl-row bbl-row-rating">
						<strong><?php esc_html_e( 'Rating', 'bookboochi-library' ); ?> :</strong>
						<span class="bbl-stars" aria-label="<?php echo esc_attr( sprintf( __( 'Rated %s out of 5', 'bookboochi-library' ), $book['_bbl_rating'] ) ); ?>"><?php echo esc_html( self::stars_html( $book['_bbl_rating'] ) ); ?></span>
					</p>
				<?php endif; ?>
			</div>
		</aside>
		<?php
		return ob_get_clean();
	}

	/**
	 * Turn a list of WP_Term objects into comma-separated links to their
	 * archive pages (e.g. every review tagged with that author/genre).
	 */
	public static function term_names( $terms ) {
		if ( empty( $terms ) || is_wp_error( $terms ) ) {
			return '';
		}
		$links = array();
		foreach ( $terms as $term ) {
			$links[] = sprintf(
				'<a href="%1$s">%2$s</a>',
				esc_url( get_term_link( $term ) ),
				esc_html( $term->name )
			);
		}
		return implode( ', ', $links );
	}
}
